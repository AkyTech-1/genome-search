import { Router, type IRouter } from "express";

const router: IRouter = Router();

const VALID_DNA = /^[ACGTNRYSWKMBDHVacgtnryswkmbdhv\s]+$/;
const NCBI_BLAST_URL = "https://blast.ncbi.nlm.nih.gov/Blast.cgi";
const HEADERS = {
  "User-Agent":
    "ViralGenomeIntelligence/2.1 (educational; tool=viral_genome_intel; email=admin@example.com)",
  Accept: "*/*",
};

// ---------------------------------------------------------------------------
// POST /api/blast/submit — proxy NCBI BLAST job submission
// ---------------------------------------------------------------------------
router.post("/blast/submit", async (req, res): Promise<void> => {
  const body = req.body as { sequence?: string };
  if (!body?.sequence) {
    res.status(400).json({ error: "Missing sequence in request body." });
    return;
  }

  const sequence = body.sequence.replace(/\s+/g, "").toUpperCase();

  if (sequence.length < 20) {
    res.status(400).json({ error: "Sequence too short — minimum 20 nucleotides." });
    return;
  }
  if (!VALID_DNA.test(body.sequence)) {
    res.status(400).json({
      error:
        "Invalid sequence. Only IUPAC DNA characters allowed (A,C,G,T,N,R,Y,S,W,K,M,B,D,H,V).",
    });
    return;
  }

  // NCBI accepts both GET and POST for CMD=Put.
  // The response may be HTML (NCBI web UI) but always embeds the RID.
  const params = new URLSearchParams({
    CMD: "Put",
    PROGRAM: "blastn",
    DATABASE: "core_nt",
    QUERY: sequence,
    FORMAT_TYPE: "JSON2",
    tool: "viral_genome_intel",
    email: "admin@example.com",
  });

  try {
    const resp = await fetch(`${NCBI_BLAST_URL}?${params.toString()}`, {
      method: "GET",
      headers: HEADERS,
      signal: AbortSignal.timeout(30_000),
    });

    if (!resp.ok) {
      res.status(502).json({ error: `NCBI returned HTTP ${resp.status}` });
      return;
    }

    const text = await resp.text();

    // RID is present both in plain text ("RID = XYZ") and in HTML responses
    // (as an input value or URL parameter). The regex covers all cases.
    const ridMatch = /\bRID\s*=\s*([A-Z0-9]+)/.exec(text);
    if (!ridMatch) {
      req.log.error({ preview: text.slice(0, 400) }, "No RID in NCBI submit response");
      res.status(502).json({
        error:
          "NCBI did not return a Job ID. The servers may be overloaded — please try again in a few seconds.",
      });
      return;
    }

    res.json({ rid: ridMatch[1] });
  } catch (err) {
    req.log.error({ err }, "Failed to contact NCBI for submit");
    res.status(502).json({ error: `Could not reach NCBI: ${String(err)}` });
  }
});

// ---------------------------------------------------------------------------
// GET /api/blast/results?rid=... — two-phase: status then results
// ---------------------------------------------------------------------------
router.get("/blast/results", async (req, res): Promise<void> => {
  const rid = typeof req.query.rid === "string" ? req.query.rid.trim() : "";
  if (!rid) {
    res.status(400).json({ error: "Missing rid query parameter." });
    return;
  }

  // ── Phase 1: lightweight status check ──────────────────────────────────────
  // FORMAT_OBJECT=SearchInfo always returns plain QBlastInfo text (not HTML)
  const statusUrl = `${NCBI_BLAST_URL}?CMD=Get&FORMAT_OBJECT=SearchInfo&RID=${encodeURIComponent(rid)}&tool=viral_genome_intel&email=admin%40example.com`;
  let statusText: string;
  try {
    const statusResp = await fetch(statusUrl, {
      headers: HEADERS,
      signal: AbortSignal.timeout(15_000),
    });
    statusText = await statusResp.text();
  } catch (err) {
    req.log.error({ err }, "Failed to check NCBI job status");
    res.status(502).json({ error: `Network error checking job status: ${String(err)}` });
    return;
  }

  if (statusText.includes("Status=UNKNOWN")) {
    res.status(404).json({
      error:
        "Job not found or expired on NCBI servers. RIDs expire after 24 hours — please resubmit.",
    });
    return;
  }

  if (statusText.includes("ThereAreHits=no")) {
    res.json({ status: "done", hits: [] });
    return;
  }

  if (
    !statusText.includes("Status=READY") ||
    statusText.includes("Status=WAITING") ||
    statusText.includes("Status=READYING")
  ) {
    res.json({ status: "waiting" });
    return;
  }

  // ── Phase 2: fetch TEXT results (reliable from cloud servers) ──────────────
  // JSON2 returns a non-standard ZIP with data descriptors (hard to parse);
  // TEXT returns the full BLAST report embedded in a thin HTML wrapper.
  const resultsUrl = `${NCBI_BLAST_URL}?CMD=Get&FORMAT_TYPE=TEXT&RID=${encodeURIComponent(rid)}&tool=viral_genome_intel&email=admin%40example.com`;
  let rawText: string;
  try {
    const resultsResp = await fetch(resultsUrl, {
      headers: HEADERS,
      signal: AbortSignal.timeout(60_000),
    });
    if (!resultsResp.ok) {
      res.status(502).json({ error: `NCBI results endpoint returned HTTP ${resultsResp.status}` });
      return;
    }
    rawText = await resultsResp.text();
  } catch (err) {
    req.log.error({ err }, "Failed to fetch NCBI results");
    res.status(502).json({ error: `Network error fetching results: ${String(err)}` });
    return;
  }

  // Strip HTML wrapper — NCBI embeds the report inside the page text
  let blastText = rawText;
  // Remove the thin HTML wrapper if present
  const preStart = rawText.indexOf("<PRE>");
  const preEnd = rawText.lastIndexOf("</PRE>");
  if (preStart !== -1) {
    blastText = preEnd !== -1
      ? rawText.slice(preStart + 5, preEnd)
      : rawText.slice(preStart + 5);
  }

  const hits = parseBlastText(blastText);
  res.json({ status: "done", hits });
});

// ---------------------------------------------------------------------------
// Parse plain-text BLAST output into structured hit objects
// ---------------------------------------------------------------------------
interface BlastHit {
  accession: string;
  title: string;
  score: number;
  evalue: string;
  identity: number;
}

function parseBlastText(text: string): BlastHit[] {
  const hits: BlastHit[] = [];

  // Find the "Sequences producing significant alignments" section
  const alignStart = text.indexOf("Sequences producing significant alignments:");
  if (alignStart === -1) return hits;

  // Scan to the end of the header line (skip two newlines)
  let pos = text.indexOf("\n", alignStart);
  if (pos === -1) return hits;
  pos = text.indexOf("\n", pos + 1); // skip blank/header line
  if (pos === -1) return hits;
  pos++; // move past second newline

  // Parse each hit line until we hit a blank line or a section header
  const lines = text.slice(pos).split("\n");
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith(">") || trimmed.startsWith("BLAST") || trimmed.startsWith("Lambda") || trimmed.startsWith("Effective")) break;

    // Format: accession  title...  score  evalue  identity%
    // The score and evalue are right-aligned; identity ends with %
    const hitMatch = /^(\S+)\s+(.+?)\s{2,}(\d+)\s+([\d.e+\-]+)\s+(\d+)%\s*$/.exec(trimmed);
    if (hitMatch) {
      hits.push({
        accession: hitMatch[1],
        title: hitMatch[2].replace(/\.\.\.$/, "").trim(),
        score: parseInt(hitMatch[3], 10),
        evalue: hitMatch[4],
        identity: parseInt(hitMatch[5], 10),
      });
    }
  }

  return hits;
}

export default router;
