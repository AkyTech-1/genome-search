import { Router, type IRouter } from "express";
import healthRouter from "./health";
import virusesRouter from "./viruses";
import blastRouter from "./blast";

const router: IRouter = Router();

router.use(healthRouter);
router.use(virusesRouter);
router.use(blastRouter);

export default router;
