import { Router, type IRouter } from "express";
import { VIRUSES } from "../lib/virusData";

const router: IRouter = Router();

router.get("/viruses", async (_req, res): Promise<void> => {
  res.json(VIRUSES);
});

export default router;
