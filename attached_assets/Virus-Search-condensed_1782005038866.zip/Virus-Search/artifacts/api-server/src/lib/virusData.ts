export interface Virus {
  id: string;
  name: string;
  fullname: string;
  family: string;
  genus: string;
  discovered: number;
  risk: number;
  status: string;
  tag: string;
  accession: string;
  description: string;
  characteristics: string[];
  genome_kb: number;
  host: string;
  sequence: string;
}

function V(
  id: string, name: string, fullname: string, family: string, genus: string,
  disc: number, risk: number, status: string, tag: string, acc: string,
  desc: string, chars: string[], kb: number, host: string, seq: string
): Virus {
  return { id, name, fullname, family, genus, discovered: disc, risk, status, tag, accession: acc, description: desc, characteristics: chars, genome_kb: kb, host, sequence: seq };
}

export const VIRUSES: Virus[] = [
  // ─── Coronaviridae ───────────────────────────────────────────────────────────
  V("sarscov2","SARS-CoV-2","Severe Acute Respiratory Syndrome Coronavirus 2","Coronaviridae","Betacoronavirus",2019,3,"characterized","COVID-19","MN908947",
    "Caused the COVID-19 pandemic. Uses spike protein to bind ACE2 receptors. Over 7 million deaths worldwide.",
    ["ssRNA(+)","Enveloped","Spike protein","ACE2 receptor","Bat origin","Global pandemic"],29.9,"Humans, bats, mammals",
    "ATGTTTGTTTTTCTTGTTTTATTGCCACTAGTCTCTAGTCAGTGTGTTAATCTTACAACCAGAACTCAATTACCCCCTGCATACACTAATTCTTTCACACGTGGTGTTTATTACC"),
  V("sarscov1","SARS-CoV-1","Severe Acute Respiratory Syndrome Coronavirus 1","Coronaviridae","Betacoronavirus",2003,3,"characterized","SARS 2003","AY278741",
    "Caused the 2003 SARS outbreak (~8,000 cases, 10% CFR). Contained by public health. Predecessor lineage to SARS-CoV-2.",
    ["ssRNA(+)","Enveloped","Spike protein","ACE2 receptor","Bat-civet origin","Contained 2003"],29.7,"Humans, palm civets, bats",
    "ATGTTTGTGTTCCTGGTCTTGCTGCCCCTGTCACTGGTGTACAATCTTACACCTCAGACTCAGATTCCCCCAGCATACACTAATTCTTTCACACATGGTGTTTATTACCC"),
  V("merscov","MERS-CoV","Middle East Respiratory Syndrome Coronavirus","Coronaviridae","Betacoronavirus",2012,3,"emerging","MERS","JX869059",
    "High-mortality (~35% CFR) respiratory pathogen using DPP4 as entry receptor. Endemic in dromedary camels.",
    ["ssRNA(+)","Enveloped","Spike protein","DPP4 receptor","Camel origin","CFR ~35%"],30.1,"Humans, dromedary camels",
    "ATGTTCGTTCTGATCTTGTTAACTGCCACGGCCACAAGCACAAATTTACACCTCAGACAAAAGTTCCCAAAGCATACAGTAATTCTTTCACATGTGGTTTCTACTACCA"),
  V("hcov229e","HCoV-229E","Human Coronavirus 229E","Coronaviridae","Alphacoronavirus",1966,1,"characterized","Common Cold CoV","NC_002645",
    "One of four common cold coronaviruses. Causes mild upper respiratory infections. Uses APN (CD13) as receptor.",
    ["ssRNA(+)","Enveloped","Spike protein","APN/CD13 receptor","Seasonal"],27.3,"Humans",
    "ATGTTTGTGTTCCTGATCTTGCTGCCCCTGGTGTTGGGCATTCAGCTTACACCTCAGACTCAGATTCCCAAAGCATACAGTAACTCTTTCATATTTGGTATTTATTACC"),
  V("hcovoc43","HCoV-OC43","Human Coronavirus OC43","Coronaviridae","Betacoronavirus",1967,1,"characterized","Common Cold CoV","NC_006213",
    "Common cold coronavirus, most prevalent seasonal CoV. Related to bovine coronavirus.",
    ["ssRNA(+)","Enveloped","Spike protein","Sialic acid receptor","Seasonal","Bovine origin"],30.7,"Humans, cattle",
    "ATGTTTGTGTTCTTGATCTTGTTGCCCCTAGTCTTGGGCATTCAGCTTACACCTCAGACCCAAATTCCTAAAGCATACAGTAATACTTTCACATGTGGTCTTTACTACC"),
  V("hcovnl63","HCoV-NL63","Human Coronavirus NL63","Coronaviridae","Alphacoronavirus",2004,1,"characterized","NL63","NC_005831",
    "Common cold coronavirus that also uses ACE2. Same receptor as SARS-CoV-2, but far less dangerous.",
    ["ssRNA(+)","Enveloped","Spike protein","ACE2 receptor","Seasonal","Mild disease"],27.5,"Humans",
    "ATGTTTGTTTTCCTAATCTTGTTGCCTCTCGTCTTGGGCATTCAGCTAACACTTCAGACGCAGATTCCCAAAGCATATAGTAATACTTTCACATGTGGTATTTATTACC"),
  V("hcovhku1","HCoV-HKU1","Human Coronavirus HKU1","Coronaviridae","Betacoronavirus",2005,1,"characterized","HKU1","NC_006577",
    "Common cold betacoronavirus discovered in Hong Kong. Causes mild respiratory illness primarily in children.",
    ["ssRNA(+)","Enveloped","Spike protein","Sialic acid receptor","Seasonal"],29.9,"Humans, rodents",
    "ATGTTTGTCTTTCTCATCTTGTTGCCCCTTGTCTTGGGCATCCAGCTTACACCTCAAACCCAAATCCCCAAAGCGTATAGTAATACTTTCACATGTGGTATCTACTACC"),
  V("ratg13","Bat CoV RaTG13","Bat Coronavirus RaTG13","Coronaviridae","Betacoronavirus",2013,3,"novel","RaTG13 \u26a0","MN996532",
    "Closest known relative of SARS-CoV-2 (96.2% genome identity). Spillover pathway remains unresolved.",
    ["ssRNA(+)","Enveloped","Spike (poor ACE2 affinity)","Bat reservoir","96.2% to SARS-CoV-2","\u26a0 Origin unknown"],29.9,"Rhinolophus affinis bats",
    "ATGTTTGTTTTTCTTGTTTTATTGCCACTAGTGTCAAGTCAGTGTGTTAATCTTACAACCAGAACTCAATTATCCCCTACATACACTAATTCTTTCACACGTGGTGTTTACTA"),
  V("banal52","BANAL-52","Bat Coronavirus BANAL-52","Coronaviridae","Betacoronavirus",2021,3,"novel","BANAL-52 \u26a0","MZ937003",
    "Laotian bat coronavirus whose receptor-binding domain is nearly identical to SARS-CoV-2.",
    ["ssRNA(+)","Enveloped","High ACE2 affinity RBD","Bat reservoir (Laos)","\u26a0 Close SARS-CoV-2 relative"],29.8,"Rhinolophus bats, Laos",
    "ATGTTTGTTTTTCTTGTTTTATTGCCACTAGTCTCAAGTCAGTGTGTTAATCTTACAACCAGAACTCAATTATCCCCTGCATACACTAATTCTTTCACACGTGGTGTTTACTA"),

  // ─── Filoviridae ─────────────────────────────────────────────────────────────
  V("ebola","Ebola Virus","Zaire Ebolavirus","Filoviridae","Ebolavirus",1976,4,"characterized","EBOV","AF086833",
    "Severe hemorrhagic fever, CFR up to 90%. Outbreaks in Central/West Africa.",
    ["ssRNA(-)","Enveloped","GP glycoprotein","Hemorrhagic fever","Bat reservoir","CFR up to 90%"],19.0,"Humans, great apes, fruit bats",
    "ATGGGTGTTACAGGAATATTGCAGTTACCTCGTGATGAAGCCAAGAATATCACCTTGGTTGAGAGACAGATTGATGATAATCAAAAAGAGATTGGAATCTTCAAGTTGAAAG"),
  V("marburg","Marburg Virus","Marburg Marburgvirus","Filoviridae","Marburgvirus",1967,4,"characterized","MARV","NC_001608",
    "Severe hemorrhagic fever, CFR up to 88%. Egyptian fruit bats are confirmed reservoir.",
    ["ssRNA(-)","Enveloped","GP glycoprotein","Hemorrhagic fever","Egyptian fruit bat","CFR up to 88%"],19.1,"Humans, primates, Egyptian fruit bats",
    "ATGGGCATCACAGGCCTCCTGCAGTTACCTCGAGATGAAGCCAAGATCATCACGTTGGTTGAAAGACAGATAGATGACAATCAAAAAGAGATTGGAATCTTTAAGTTGAAAAG"),
  V("sudanebola","Sudan Ebolavirus","Sudan Ebolavirus","Filoviridae","Ebolavirus",1976,4,"characterized","SUDV","NC_006432",
    "Second most common Ebola species. ~50% CFR. Several outbreaks in Sudan and Uganda.",
    ["ssRNA(-)","Enveloped","GP glycoprotein","Hemorrhagic fever","Bat reservoir","CFR ~50%"],18.9,"Humans, great apes",
    "ATGGGGGTGACAGGGCTACTACAATTACCTCGGGATGAAGCCAAGATCATAACACTGGTTGAAAGACAGATCGATGATAATCAGAAAGAAATTGGGATCTTCAAGTTGAAAG"),
  V("bundiebola","Bundibugyo Ebolavirus","Bundibugyo Ebolavirus","Filoviridae","Ebolavirus",2007,4,"characterized","BDBV","NC_014373",
    "Discovered in Uganda in 2007. ~30% CFR — least lethal of the three human-pathogenic Ebola species.",
    ["ssRNA(-)","Enveloped","GP glycoprotein","Hemorrhagic fever","Bat reservoir","CFR ~30%"],19.0,"Humans",
    "ATGGGAGTGACAGGGTTACTACAGTTACCTCGAGATGAAGCCAAGATCATAACTCTGGTTGAAAGACAGATCGATGACAACCAGAAAGAAATCGGAATCTTCAAGCTGAAAG"),

  // ─── Paramyxoviridae / Henipavirus ───────────────────────────────────────────
  V("nipah","Nipah Virus","Nipah Henipavirus","Paramyxoviridae","Henipavirus",1999,4,"emerging","NiV","AJ564623",
    "Fatal encephalitis and respiratory disease. WHO pandemic priority pathogen. CFR 40–75%.",
    ["ssRNA(-)","Enveloped","F/G fusion protein","Ephrin B2/B3","Bat origin (Pteropus)","CFR 40-75%","Pandemic potential"],18.2,"Humans, pigs, Pteropus bats",
    "ATGAAAGCAATCCTGTCTTTAAGCAGTGCCTCCAATCAGCCTCCCAAACCAAAGCAGACAAATCCAAAAACAGCCCTGCAAACCACAAGGAAGCAAAATCGACAGCTGTGG"),
  V("hendra","Hendra Virus","Hendra Henipavirus","Paramyxoviridae","Henipavirus",1994,4,"characterized","HeV","NC_001906",
    "Fatal in humans and horses. Pteropus bat reservoir in Australia. Person-to-person spread not documented.",
    ["ssRNA(-)","Enveloped","F/G fusion protein","Ephrin B2/B3","Australian bat reservoir","Horse intermediate"],18.2,"Humans, horses, Pteropus bats",
    "ATGAAAGCAATCCTGTCTTTAAGCAGTGCCTCCAATCAGCCTCCCAAACCAAAGCAGACAAATCCAAAAACAGCCCTGCAAACCACAAGGAAGCAAAATCGACAGCTGTGG"),
  V("measles","Measles Virus","Measles Morbillivirus","Paramyxoviridae","Morbillivirus",1758,2,"characterized","MeV","NC_001498",
    "Highly contagious. Causes rash, fever, immune amnesia. Vaccine available. Still kills ~200,000/yr globally.",
    ["ssRNA(-)","Enveloped","H/F glycoproteins","CD150/Nectin-4 receptor","Airborne","Immune amnesia","Vaccine available"],15.9,"Humans",
    "ATGGGCAAGAGGGCGATCAAAGAGTTCCTGAACAAGAGCCTGTGCATCAGCCTGACAGAGGACCAGAAGGAGAATGACATCATGATCTTCAAGAACATGGATGTCATCAAGAG"),
  V("mumps","Mumps Virus","Mumps Orthorubulavirus","Paramyxoviridae","Orthorubulavirus",1934,1,"characterized","MuV","NC_002200",
    "Causes mumps (parotitis), orchitis, and meningitis. MMR vaccine very effective.",
    ["ssRNA(-)","Enveloped","HN/F glycoproteins","CD4 receptor","Salivary spread","Orchitis","Vaccine available"],15.3,"Humans",
    "ATGGAAATCCTGTCTATGCTTAACAATACAACAGAAAGAAACAAACTGGCAGTCATCATCAGCAATCATCGTCATCATCATCATCATCATCATCATCATCATCATCATCATCA"),

  // ─── Flaviviridae ─────────────────────────────────────────────────────────────
  V("dengue","Dengue Virus 2","Dengue Virus (Serotype 2)","Flaviviridae","Flavivirus",1943,2,"characterized","DENV-2","NC_001474",
    "~400M infections/yr globally. Hemorrhagic dengue can be fatal. Four serotypes. Aedes mosquito vector.",
    ["ssRNA(+)","Enveloped","E glycoprotein","AXL/DC-SIGN receptor","Aedes mosquito vector","Four serotypes","Antibody-dependent enhancement"],10.7,"Humans, Aedes mosquitoes",
    "ATGAATAACCAACGGAAAGGTGGGTCGATATTCAAGATTTCAGGAATCAATACCAACAGCAATAATGAATGGGAGTGTAGTGGAGTTGATAAACCAAGACATGATGGCAATCAA"),
  V("zika","Zika Virus","Zika Virus","Flaviviridae","Flavivirus",1947,2,"emerging","ZIKV","KX369547",
    "Caused 2015-16 epidemic. Linked to microcephaly in newborns and Guillain-Barré syndrome. Aedes mosquito.",
    ["ssRNA(+)","Enveloped","E glycoprotein","AXL receptor","Aedes mosquito","Microcephaly","Sexual transmission"],10.8,"Humans, Aedes mosquitoes",
    "ATGAAAAACCCAAACAAAGAAATGTGGATCTTTGGATTTCCGGGCAATGCAGGAGTGTTCGTTGATCTCAAACAAGGCACCCGGATCGGTCCCCGGCAAGGACCTCGGTGCTAA"),
  V("westnilevirus","West Nile Virus","West Nile Virus (Lineage 1)","Flaviviridae","Flavivirus",1937,2,"emerging","WNV","NC_009942",
    "Culex mosquito vector. Causes encephalitis. Endemic in Americas since 1999. Most infections asymptomatic.",
    ["ssRNA(+)","Enveloped","E glycoprotein","Culex mosquito vector","Bird amplifying hosts","Neuroinvasive disease"],11.0,"Humans, birds, Culex mosquitoes",
    "ATGATCAAGATAACAGCAATAGAAATAGATGGAGAAGCACAGAAAAGAACAAAGCAACAAGAAAAAGAACAAGAAAAAAGAGAAGAAGAAGAAGAAGAAGAAGAAGAAGAAGAA"),
  V("yellowfever","Yellow Fever Virus","Yellow Fever Virus","Flaviviridae","Flavivirus",1900,3,"characterized","YFV","X03700",
    "Vaccine-preventable viral hemorrhagic fever. Aedes aegypti vector. High CFR without treatment.",
    ["ssRNA(+)","Enveloped","E glycoprotein","Aedes aegypti vector","Hepatitis/hemorrhage","CFR 20-50% severe","Vaccine available"],10.9,"Humans, monkeys, Aedes mosquitoes",
    "ATGAAGAAATCAAACAGAGACTTCGTTGATCTTACCCAGAAGCAAGAGAAGTTCAAAGACAACCAGAAGACCCAGAACAAGGAGCAGAGAGAGAAGAAGAAGAAGAAGAAGAAG"),
  V("hcv","Hepatitis C Virus","Hepatitis C Virus (Genotype 1a)","Flaviviridae","Hepacivirus",1989,2,"characterized","HCV","NC_004102",
    "~58M chronically infected globally. Major cause of liver cirrhosis and hepatocellular carcinoma. Curative DAAs exist.",
    ["ssRNA(+)","Enveloped","E1/E2 glycoproteins","CD81/SR-BI receptor","Bloodborne","Chronic hepatitis","Curable with DAAs"],9.6,"Humans",
    "ATGAGCACGAATCCTAAACCTCAAAGAAAAACCAAACGTAACACCAACCGTCGCCCACAGGACGTCAAGTTCCCGGGCGGTCGTCAGAATCCAGAATTTGGCCATGAATCACTCC"),

  // ─── Bunyaviridae / Hantaviridae ─────────────────────────────────────────────
  V("hantaan","Hantaan Virus","Hantaan Orthohantavirus","Hantaviridae","Orthohantavirus",1978,3,"characterized","HTNV","NC_005218",
    "Causes hemorrhagic fever with renal syndrome (HFRS) in Asia. Striped field mouse reservoir. CFR 5-15%.",
    ["ssRNA(-)","Enveloped","Gn/Gc glycoproteins","Striped field mouse reservoir","Rodent feces aerosol","HFRS","Korea/China"],11.8,"Humans, Apodemus agrarius",
    "ATGAGCAAGCCAACAGCAGGCACTCGCCAAGTCACAAAGCAAGGGGAAAGGAGGCCAAGAAATGTCTGGAGATCACGATCGAAGAAATCACAGAAATGCAAACAGAGACCCTGG"),
  V("sin_nombre","Sin Nombre Virus","Sin Nombre Orthohantavirus","Hantaviridae","Orthohantavirus",1993,3,"characterized","SNV","NC_005216",
    "Causes hantavirus pulmonary syndrome. Deer mouse reservoir in North America. CFR ~35%.",
    ["ssRNA(-)","Enveloped","Gn/Gc glycoproteins","Deer mouse reservoir","Pulmonary syndrome","CFR ~35%","North America"],11.8,"Humans, Peromyscus maniculatus",
    "ATGAGCAAACCTACTGCAGGTACTCGGCAAGTCACAAAGCAAGGAGAAAGGAGGCCAAGAAATGTCAGGAGATCACGATTGAAGAAATCACAGAAATGCAGACAGAGACCCTGG"),
  V("crimean_congo","Crimean-Congo HF Virus","Crimean-Congo Hemorrhagic Fever Orthonairovirus","Nairoviridae","Orthonairovirus",1944,4,"characterized","CCHFV","NC_005302",
    "Tick-borne hemorrhagic fever. CFR up to 40%. Hyalomma tick vector. Endemic across Africa, Asia, Europe.",
    ["ssRNA(-)","Enveloped","Gn/Gc glycoproteins","Hyalomma tick vector","Hemorrhagic fever","CFR up to 40%"],19.2,"Humans, livestock, ticks",
    "ATGGAAACTTCAGAACAACTAAACACATTAGCAACTCTCAAGGAGAACAGGATGAGGATACAGCAAATTCATGCAGAAGATATTGATGAAGGAAAGCAAGGAGATCAAAAAATGG"),

  // ─── Togaviridae ──────────────────────────────────────────────────────────────
  V("chikungunya","Chikungunya Virus","Chikungunya Virus","Togaviridae","Alphavirus",1952,2,"emerging","CHIKV","NC_004162",
    "Mosquito-borne alphavirus causing severe debilitating arthritis. Major global outbreaks since 2004.",
    ["ssRNA(+)","Enveloped","E1/E2 glycoproteins","Aedes mosquito vector","Severe arthritis","Global spread"],11.8,"Humans, Aedes mosquitoes",
    "ATGGATCTGCCCGCATACGTCGCATCGTCAGTCGTCGCCATCGCACTCGCACTTGGCGTCGCCGTTGTCTAATCATGAGTGGACTGCAGCCAGCGCAGCATGGCGCAGCGCCAA"),
  V("rubella","Rubella Virus","Rubella Virus","Togaviridae","Rubivirus",1962,1,"characterized","RUBV","NC_001545",
    "Causes German measles and congenital rubella syndrome. MMR vaccine very effective.",
    ["ssRNA(+)","Enveloped","E1/E2 glycoproteins","Highly contagious","Congenital defects","Vaccine available"],9.8,"Humans",
    "ATGTCCACGCCCGCAAGGCCCACGACACCTTTTAAGCAGGGCAATCCCACAAGGCATGCTCCCGTTTAAGGCACCCGATTATACCAGCAGCCAAGACCCAAACAGAACCCCTGG"),

  // ─── Arenaviridae ─────────────────────────────────────────────────────────────
  V("lassa","Lassa Fever Virus","Lassa Mammarenavirus","Arenaviridae","Mammarenavirus",1969,4,"emerging","LASV","NC_004296",
    "Causes Lassa fever in West Africa. ~300,000 infections/yr. Multimammate rat reservoir.",
    ["ssRNA(-)","Enveloped","GP glycoprotein","Multimammate rat reservoir","Hemorrhagic fever","CFR 15-25% in severe cases"],10.7,"Humans, Mastomys natalensis",
    "ATGGGACAAATAGTGGTTCAGATTCAGGGACTTGCTCCAGTCCAAGACATCCAGGGAGTTTTTTCCAGTACCAATGGAAATGGAACAGAGCCTCCAGCTGGAGCACAAGCCC"),
  V("junin","Junin Virus","Junin Mammarenavirus","Arenaviridae","Mammarenavirus",1958,4,"characterized","JUNV","NC_005081",
    "Causes Argentine hemorrhagic fever. Corn mouse reservoir. Seasonal outbreaks in Pampas.",
    ["ssRNA(-)","Enveloped","GP glycoprotein","Corn mouse reservoir","Hemorrhagic fever","Argentina endemic","Vaccine available"],11.1,"Humans, Calomys musculinus",
    "ATGGGACAGATAGTGGTTCAGATTCAGGGACTTGCACCGGTGCAAGACATCCAAGGGGTCTTCTCAAGTACCAATGGAAATGGAACAGAGCCTCCAGCTGGAGCACAAGCAC"),

  // ─── Orthomyxoviridae ─────────────────────────────────────────────────────────
  V("h5n1","H5N1 Influenza","Influenza A Virus (H5N1)","Orthomyxoviridae","Alphainfluenzavirus",1997,3,"emerging","HPAI H5N1","CY014659",
    "Highly pathogenic avian influenza. CFR >60% in humans. Spreading in dairy cattle since 2024.",
    ["ssRNA(-)","Enveloped","HA (H5) hemagglutinin","NA (N1) neuraminidase","Avian origin","CFR >60%","Pandemic potential"],13.6,"Birds, humans (sporadic), dairy cattle",
    "ATGAAGGCAATACTAGTAGTTATGCTATATACATTCGCAAGCATGGCAATAGTCAAAAGCAATCGGGCAGATAATACTAATATTAGTTTCAGAGAATACAAATGCAGACAATCTTG"),
  V("h1n12009","H1N1 (2009)","Influenza A Virus (H1N1) pdm09","Orthomyxoviridae","Alphainfluenzavirus",2009,2,"characterized","H1N1 pdm09","CY121682",
    "Caused the 2009 swine flu pandemic. Reassortant from swine/avian/human strains.",
    ["ssRNA(-)","Enveloped","HA (H1) hemagglutinin","Triple-reassortant origin","Pandemic 2009","Swine/avian lineage"],13.6,"Humans, pigs",
    "ATGAAGGCAATACTCGTCGTTACGCTAATCTTCTGTCAGGCCATCGCCAGCGACAATGCAGACACAATATGTATAGGCTACCATGCAAATAATCAAACGGAAAGAGTTGGATAG"),
  V("h3n2","H3N2 Influenza","Influenza A Virus (H3N2)","Orthomyxoviridae","Alphainfluenzavirus",1968,2,"characterized","H3N2 Seasonal","KF848938",
    "Dominant seasonal flu strain. Originated from 1968 Hong Kong pandemic. Constant antigenic drift.",
    ["ssRNA(-)","Enveloped","HA (H3) hemagglutinin","High antigenic drift","Seasonal epidemic"],13.6,"Humans, pigs, birds",
    "ATGAAGACTATCATTGCTTTGAGCTACATCTTCTGTCTGGTCTTTGCCGACAGCACAATAAGGAACAACAGTACTTCAATTTGGTCACAATCACAAACTCAAAAAGCAGACAAT"),

  // ─── Rhabdoviridae ────────────────────────────────────────────────────────────
  V("rabies","Rabies Virus","Rabies Lyssavirus","Rhabdoviridae","Lyssavirus",1903,3,"characterized","RABV","NC_001542",
    "100% fatal once symptomatic. Bullet-shaped RNA virus infecting CNS. Vaccine effective if given promptly.",
    ["ssRNA(-)","Enveloped","G glycoprotein","Neural tropism","Bite transmission","100% fatal if untreated","Vaccine available"],11.9,"Humans, mammals",
    "ATGTTCACAGGCTCCTTGCCGGATGAGAAAACTAAAGAGTTTCAAATCCCGAATCAAGGCAAACAAGGGGGCAAAGAGAGCATCTGAGTTCCTTAATCAAGAGCTGGACCAAG"),

  // ─── Picornaviridae ───────────────────────────────────────────────────────────
  V("poliovirus","Poliovirus","Poliovirus (Type 1 Wild)","Picornaviridae","Enterovirus",1909,2,"characterized","PV-1","NC_002058",
    "Causes poliomyelitis — irreversible paralysis. Wild type 2 and 3 eradicated. Type 1 remains in Pakistan/Afghanistan.",
    ["ssRNA(+)","Non-enveloped","VP1-VP4 capsid","CD155/PVR receptor","Fecal-oral spread","Paralysis","Near eradication"],7.4,"Humans",
    "ATGGGTTCAGGTCGCGGTGGAGATCCCACTATCCAGCAGCAGCAGCAACAGCAGCAGCAGCAACAGCAGCAGCAGCAGCAAACCACGCCACCACCACCACCACCACCACCAC"),

  // ─── Retroviridae ─────────────────────────────────────────────────────────────
  V("hiv1","HIV-1","Human Immunodeficiency Virus 1 (Clade B)","Retroviridae","Lentivirus",1983,3,"characterized","HIV-1","NC_001802",
    "Causes AIDS. ~38M living with HIV globally. Uses CD4/CCR5 to infect T-cells. Highly effective ART exists.",
    ["ssRNA(+)","Enveloped","gp120/gp41 glycoproteins","CD4/CCR5 receptor","Sexual/bloodborne","Destroys immune system","ART treatable"],9.7,"Humans",
    "ATGGGTGCGAGAGCGTCAGTATTAAGCGGGGGAAAATTAGATGCATGGGAAAAAATTCGGTTAAGGCCAGGGGGAAAGAAAAAATATAAATTAAAACATATAGTATGGGCAAGC"),
  V("hiv2","HIV-2","Human Immunodeficiency Virus 2","Retroviridae","Lentivirus",1986,3,"characterized","HIV-2","NC_001722",
    "Less virulent than HIV-1. Slower disease progression. Endemic in West Africa.",
    ["ssRNA(+)","Enveloped","gp105/gp36 glycoproteins","CD4/CCR5 receptor","Sexual/bloodborne","West Africa endemic"],9.7,"Humans",
    "ATGGGTGCGAGAGCGTCAGTATTAAGTGGGGGAAAATTAGATGCATGGGAGAAAATTCGCTTAAGGCCAGGGGGAAAGAAACGATATAAACTAAAACATATAGTATGGGCAAGC"),

  // ─── Herpesviridae ────────────────────────────────────────────────────────────
  V("hsv1","Herpes Simplex 1","Human Herpesvirus 1","Herpesviridae","Simplexvirus",1919,1,"characterized","HSV-1","JQ673480",
    "Causes oral herpes (cold sores) and keratitis. Establishes lifelong latency in trigeminal ganglia.",
    ["dsDNA","Enveloped","gC/gB/gD glycoproteins","Latent in neurons","Reactivation","Oral herpes / encephalitis"],152.0,"Humans",
    "ATGGCCTCGGACATCGCCCGCGACATCGCCTTCATGGTGTTGCTGCGGCGCTACACGCAGCACGAGCAGACCATCACCGAGGTGGGCGGCAACATCATCCCGCACATGTGCAAGG"),
  V("ebv","Epstein-Barr Virus","Human Herpesvirus 4","Herpesviridae","Lymphocryptovirus",1964,2,"characterized","EBV","NC_007605",
    "Infects >95% of adults globally. Causes infectious mononucleosis. Associated with several lymphomas.",
    ["dsDNA","Enveloped","gp350/220 glycoprotein","CD21 (CR2) receptor","B-cell latency","Mononucleosis","Oncogenic"],172.0,"Humans",
    "ATGGCGGCAGGAACAGCCATCCAGGGTCCAGAGAAGACTGCAAGCCAGGAGAAAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAAACAAAC"),
  V("cmv","Cytomegalovirus","Human Herpesvirus 5","Herpesviridae","Cytomegalovirus",1956,2,"characterized","HCMV","NC_006273",
    "Usually asymptomatic in healthy adults. Causes severe congenital defects in newborns.",
    ["dsDNA","Enveloped","gB/gH glycoproteins","Multiple receptors","Latent in myeloid cells","Congenital deafness/disability"],236.0,"Humans",
    "ATGGAGGTGGCACGGCCCAGCAGCCCGGAGCGGCTGGCAGAGCAGCAGGGCAAGCCACCGAGGGCAGAGAGCGCGGCAGAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAA"),
  V("vzv","Varicella-Zoster Virus","Human Herpesvirus 3","Herpesviridae","Varicellovirus",1953,2,"characterized","VZV","NC_001348",
    "Causes chickenpox (primary) and shingles (reactivation). Vaccine available.",
    ["dsDNA","Enveloped","gE/gB glycoproteins","Neural latency","Highly contagious","Reactivates as shingles","Vaccine available"],124.9,"Humans",
    "ATGGCCCGCGTGGCCGCACAGATTGCAGCGAACAAACAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAGCAG"),

  // ─── Poxviridae ───────────────────────────────────────────────────────────────
  V("mpox","Mpox Virus","Monkeypox Virus (Clade IIb)","Poxviridae","Orthopoxvirus",1958,3,"emerging","MPXV","NC_063383",
    "Re-emerging DNA poxvirus. 2022 global outbreak via sexual contact. JYNNEOS vaccine effective.",
    ["dsDNA","Complex enveloped","A-type inclusions","Cytoplasmic replication","Rodent reservoir","Human-to-human spread"],197.0,"Humans, rodents, primates",
    "ATGGATAGCAAAATACACTTATTATCAGACCAATTATCCAAAGATGTTATATTTTTTGGAAGAGTAAATGCACCAGAAAATGATCTTAAAAAGATCGCAAACATGTATAATAAT"),
  V("smallpox","Variola Major","Variola Major (Smallpox)","Poxviridae","Orthopoxvirus",1796,4,"characterized","VARV \u2020 Eradicated","NC_001611",
    "Eradicated in 1980. Deadliest infectious disease in history (~300M deaths in 20th century).",
    ["dsDNA","Complex enveloped","A-type inclusions","Cytoplasmic replication","Eradicated 1980","Stocks secured"],186.0,"Humans only",
    "ATGGATTCGACAAGGCCAATCAAGAGCAGCAGCAGGAGCAACAAGTGCAGCAGCAGCAACAGCAGCAGCAGCAGCAACACAAGACCAGCAGGAGGTACAGCAGCAGCAACAGCAA"),
  V("alaskapox","Alaskapox Virus","Alaskapox Virus","Poxviridae","Orthopoxvirus",2015,3,"novel","AKPV \u26a0","MW439810",
    "Novel poxvirus discovered in Alaska (2015). First human fatality in 2024. Small mammal (shrew) reservoir.",
    ["dsDNA","Complex enveloped","Orthopoxvirus proteins","Shrew reservoir","\u26a0 Recently fatal in humans","Rare"],213.0,"Humans, small mammals (shrews)",
    "ATGGACTCAACTAAAGCCAACCAAGAGCAGCAGCAAGAGCAACAAGTACAGCAGCAGCAGCAACAGCAGCAGCAGCAACACAAGACCAGCTGGAGGTGCAGCAGCAGCAGCAGCAG"),

  // ─── Hepadnaviridae ───────────────────────────────────────────────────────────
  V("hbv","Hepatitis B Virus","Hepatitis B Virus (Genotype D)","Hepadnaviridae","Orthohepadnavirus",1965,3,"characterized","HBV","NC_003977",
    "~300M chronically infected globally. Causes cirrhosis and hepatocellular carcinoma. Effective vaccine since 1982.",
    ["Partially dsDNA","Enveloped","HBsAg surface antigen","NTCP receptor","Bloodborne/sexual","Chronic liver disease","Vaccine available"],3.2,"Humans, great apes",
    "ATGGGAGGTCTTTCAGCCTTTGGAAGTTCTGCGACGTGGGAGTTCTTTTTTGCTTTCAGTTTATGTAATTTTTTTGTTAAATTTTTTTCACCTTATATAATCACTTGATCTTAT"),

  // ─── Caliciviridae ────────────────────────────────────────────────────────────
  V("norovirus","Norovirus GII.4","Norovirus (Genogroup II, Genotype 4)","Caliciviridae","Norovirus",1968,1,"characterized","NoV GII.4","GU445325",
    "Most common cause of acute gastroenteritis globally (~700M cases/yr). Extremely contagious.",
    ["ssRNA(+)","Non-enveloped","VP1/VP2 capsid","HBGA receptor","Fecal-oral","Highly contagious","Gastroenteritis"],7.6,"Humans",
    "ATGAAGATGGCGTCGAATGACGCCAAGGCCATCACGTTTTATGGTGGGACGTGCTTCCCTCAGACGAAGGGGCCGCGCCGGCCTTTCAGCAGTATCTTCCTCAGCAGCAGCAG"),

  // ─── Reoviridae ───────────────────────────────────────────────────────────────
  V("rotavirus","Rotavirus A","Rotavirus A (Strain P[8]G1)","Reoviridae","Rotavirus",1973,1,"characterized","RV-A","NC_011503",
    "Leading cause of severe childhood diarrhea globally. ~200,000 deaths/yr in under-5s.",
    ["dsRNA","Non-enveloped","VP4/VP7 capsid","Integrin/Hsc70 receptor","Fecal-oral","Pediatric gastroenteritis","Vaccine available"],18.5,"Humans, mammals",
    "ATGGCTAAAGCAAAGCTTTTAAGACAAGCCACATTCACATCAAAGCAAGTAAAACAAAAGCAAATGCAGAAACAGCAGCAGCAGCAGCAACAACAGCAGCAGCAGCAGCAACA"),

  // ─── Novel / Emerging ─────────────────────────────────────────────────────────
  V("langya","Langya Henipavirus","Langya Henipavirus (LayV)","Paramyxoviridae","Henipavirus",2022,4,"novel","LayV \u26a0","MZ526680",
    "Discovered in China 2022. 35 human infections. Shrew reservoir. Human-to-human transmission status unknown.",
    ["ssRNA(-)","Enveloped","Novel fusion protein","Shrew reservoir","\u26a0 Transmission unknown","\u26a0 No treatment"],18.4,"Humans (zoonotic), shrews",
    "ATGAAAGCAATCCTGTCACTAAGCAGTGCCTCCAGTCAGCCCCCCAAACCAAAACAGACAAACCCAAAAACAACCCTGCAAATCACAAGGAAGCAAAATCAACAGCTGTGG"),
  V("khosta2","Khosta-2 Virus","Khosta-2 Sarbecovirus","Coronaviridae","Betacoronavirus",2022,3,"novel","Khosta-2 \u26a0","MZ190137",
    "Bat sarbecovirus from Russia (2022) that binds human ACE2. Resistant to current COVID vaccines.",
    ["ssRNA(+)","Enveloped","ACE2-binding spike","Russian bat reservoir","Vaccine-resistant spike","\u26a0 Pandemic potential"],29.5,"Rhinolophus bats (Russia)",
    "ATGTTTGTCTTTCTTGTTTTATTGCCACTGGTCTCAAGTCAGTGTGTTAATCTTACAACCAGAACTCAATTATCCCCTGCATACACTAATCCTTTCACATGTGGTGTTTACTA"),
  V("oropouche","Oropouche Virus","Oropouche Orthobunyavirus","Peribunyaviridae","Orthobunyavirus",1955,3,"emerging","OROV","NC_005776",
    "Arboviral fever in Amazon region. Midge vector (Culicoides paraensis). Large outbreaks in Brazil.",
    ["ssRNA(-)","Enveloped","Gn/Gc glycoproteins","Culicoides midge vector","Febrile illness","Amazonian endemic"],12.2,"Humans, sloths, birds, midges",
    "ATGGAGCAGTATTTGGAAGATGACAAGAGTTTTGATGATTCTGCAGATCTAGAGCATCAGCTTGATTGGAGAGCTGAGAAGAAAATCAAGGATATAAGCACAGCAATGGCGGAC"),
];
