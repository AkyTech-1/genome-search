export interface ClinicalProfile {
  family: string;
  symptoms: Array<{ name: string; severity: "mild" | "moderate" | "severe" | "critical" }>;
  transmission: string[];
  vaccines: Array<{ name: string; platform: string; status: "licensed" | "emergency" | "clinical_trial" | "research" }>;
  treatments: Array<{ name: string; type: string }>;
  incubation: string;
  cfr: string;
  pandemicPotential: "low" | "moderate" | "high" | "very_high";
  organSystems: string[];
  confidence: number;
}

const FAMILY_PROFILES: Record<string, ClinicalProfile> = {
  Coronaviridae: {
    family: "Coronaviridae",
    symptoms: [
      { name: "Fever (>38°C)", severity: "moderate" },
      { name: "Persistent dry cough", severity: "moderate" },
      { name: "Dyspnea / shortness of breath", severity: "severe" },
      { name: "Fatigue & myalgia", severity: "moderate" },
      { name: "Loss of taste/smell (anosmia)", severity: "moderate" },
      { name: "Pneumonia / ground-glass opacity", severity: "severe" },
      { name: "Acute respiratory distress syndrome", severity: "critical" },
      { name: "Cytokine storm syndrome", severity: "critical" },
      { name: "Gastrointestinal disturbance", severity: "mild" },
      { name: "Long COVID / post-acute sequelae", severity: "moderate" },
    ],
    transmission: ["Respiratory droplets (primary)", "Aerosol (enclosed spaces)", "Direct contact (less common)", "Fomites (limited)"],
    vaccines: [
      { name: "mRNA-1273 (Spikevax)", platform: "Lipid nanoparticle mRNA", status: "licensed" },
      { name: "BNT162b2 (Comirnaty)", platform: "Lipid nanoparticle mRNA", status: "licensed" },
      { name: "ChAdOx1 (Vaxzevria)", platform: "Adenoviral vector", status: "licensed" },
      { name: "Ad26.COV2.S (Janssen)", platform: "Adenoviral vector", status: "licensed" },
      { name: "NVX-CoV2373 (Nuvaxovid)", platform: "Recombinant nanoparticle protein", status: "licensed" },
    ],
    treatments: [
      { name: "Nirmatrelvir/ritonavir (Paxlovid)", type: "Protease inhibitor" },
      { name: "Remdesivir (Veklury)", type: "Polymerase inhibitor" },
      { name: "Dexamethasone", type: "Corticosteroid (severe disease)" },
      { name: "Baricitinib / Tocilizumab", type: "JAK/IL-6 inhibitor" },
    ],
    incubation: "2–14 days (median 5–7 days)",
    cfr: "0.1–35% depending on strain and host",
    pandemicPotential: "very_high",
    organSystems: ["Respiratory", "Cardiovascular", "Neurological", "Renal", "Gastrointestinal"],
    confidence: 92,
  },

  Filoviridae: {
    family: "Filoviridae",
    symptoms: [
      { name: "Sudden high fever (>39°C)", severity: "severe" },
      { name: "Severe headache & myalgia", severity: "severe" },
      { name: "Hemorrhagic manifestations", severity: "critical" },
      { name: "Vomiting & diarrhea (profuse)", severity: "severe" },
      { name: "Internal & external bleeding", severity: "critical" },
      { name: "Disseminated intravascular coagulation", severity: "critical" },
      { name: "Multi-organ failure", severity: "critical" },
      { name: "Petechiae / purpura", severity: "severe" },
      { name: "Shock & circulatory collapse", severity: "critical" },
    ],
    transmission: ["Direct contact with infected bodily fluids", "Contact with infected animal", "Nosocomial spread (needlestick)", "Burial rituals (fomite contact)"],
    vaccines: [
      { name: "Ervebo (rVSV-ZEBOV)", platform: "Recombinant VSV vector", status: "licensed" },
      { name: "Zabdeno + Mvabea", platform: "Ad26/MVA prime-boost", status: "licensed" },
      { name: "Sudan Ebola candidate (ChAd3-SUDV)", platform: "Adenoviral vector", status: "clinical_trial" },
      { name: "Marburg vaccine (cAd3-MARV)", platform: "Adenoviral vector", status: "clinical_trial" },
    ],
    treatments: [
      { name: "Inmazeb (atoltivimab/maftivimab/odesivimab)", type: "Monoclonal antibody cocktail" },
      { name: "Ebanga (ansuvimab)", type: "Monoclonal antibody" },
      { name: "Supportive care & fluid replacement", type: "Intensive care" },
    ],
    incubation: "2–21 days",
    cfr: "25–90% depending on species",
    pandemicPotential: "high",
    organSystems: ["Hepatic", "Hematopoietic", "Cardiovascular", "Renal", "Neurological"],
    confidence: 94,
  },

  Orthomyxoviridae: {
    family: "Orthomyxoviridae",
    symptoms: [
      { name: "Abrupt high fever", severity: "moderate" },
      { name: "Severe myalgia & arthralgia", severity: "moderate" },
      { name: "Headache & retro-orbital pain", severity: "moderate" },
      { name: "Non-productive cough", severity: "moderate" },
      { name: "Rhinorrhea & sore throat", severity: "mild" },
      { name: "Pneumonia (severe strains)", severity: "severe" },
      { name: "Cytokine storm (H5N1/H1N1)", severity: "critical" },
      { name: "Encephalopathy (rare)", severity: "severe" },
    ],
    transmission: ["Respiratory droplets", "Aerosol transmission", "Fomite contact (limited)", "Zoonotic (avian/swine strains)"],
    vaccines: [
      { name: "Seasonal IIV4 (Fluzone/Fluarix)", platform: "Inactivated quadrivalent", status: "licensed" },
      { name: "FluBlok (Flublok Quadrivalent)", platform: "Recombinant hemagglutinin", status: "licensed" },
      { name: "LAIV4 (FluMist)", platform: "Live attenuated intranasal", status: "licensed" },
      { name: "H5N1 pre-pandemic vaccine (AUDENZ)", platform: "Adjuvanted inactivated", status: "licensed" },
      { name: "mRNA H5N1 candidates (Moderna/Pfizer)", platform: "mRNA", status: "clinical_trial" },
    ],
    treatments: [
      { name: "Oseltamivir (Tamiflu)", type: "Neuraminidase inhibitor" },
      { name: "Zanamivir (Relenza)", type: "Neuraminidase inhibitor" },
      { name: "Baloxavir marboxil (Xofluza)", type: "Cap-dependent endonuclease inhibitor" },
      { name: "Peramivir (Rapivab)", type: "Neuraminidase inhibitor (IV)" },
    ],
    incubation: "1–4 days",
    cfr: "0.01–60% depending on strain (H5N1 highest)",
    pandemicPotential: "very_high",
    organSystems: ["Respiratory", "Neurological", "Cardiovascular"],
    confidence: 90,
  },

  Retroviridae: {
    family: "Retroviridae",
    symptoms: [
      { name: "Acute retroviral syndrome (flu-like)", severity: "moderate" },
      { name: "Persistent lymphadenopathy", severity: "mild" },
      { name: "Progressive CD4+ T-cell depletion", severity: "severe" },
      { name: "Opportunistic infections", severity: "critical" },
      { name: "Kaposi's sarcoma", severity: "severe" },
      { name: "AIDS-defining illnesses", severity: "critical" },
      { name: "Night sweats & weight loss", severity: "moderate" },
      { name: "Neurocognitive decline (late)", severity: "severe" },
    ],
    transmission: ["Unprotected sexual contact", "Contaminated blood products/needles", "Vertical mother-to-child", "Breastfeeding"],
    vaccines: [
      { name: "RV144 (ALVAC+AIDSVAX)", platform: "Canarypox + gp120 protein (partial efficacy)", status: "research" },
      { name: "BG505 SOSIP trimer vaccines", platform: "Broadly neutralizing Abs target", status: "clinical_trial" },
      { name: "mRNA-based HIV vaccines", platform: "mRNA coding env/gag", status: "clinical_trial" },
    ],
    treatments: [
      { name: "HAART / ART regimens", type: "Combination antiretroviral" },
      { name: "PrEP (Truvada / Descovy)", type: "Pre-exposure prophylaxis" },
      { name: "Bictegravir/FTC/TAF (Biktarvy)", type: "Integrase strand transfer inhibitor" },
      { name: "Cabotegravir + rilpivirine (Cabenuva)", type: "Long-acting injectable ART" },
    ],
    incubation: "2–4 weeks (acute); years to AIDS",
    cfr: "Near 100% untreated; near 0% with ART",
    pandemicPotential: "high",
    organSystems: ["Immune system", "Neurological", "Hepatic", "Lymphatic"],
    confidence: 91,
  },

  Flaviviridae: {
    family: "Flaviviridae",
    symptoms: [
      { name: "Biphasic fever", severity: "moderate" },
      { name: "Severe arthralgia & myalgia", severity: "moderate" },
      { name: "Maculopapular rash", severity: "mild" },
      { name: "Retro-orbital pain", severity: "moderate" },
      { name: "Hemorrhagic manifestations (dengue/YFV)", severity: "severe" },
      { name: "Hepatitis / jaundice (YFV/HCV)", severity: "severe" },
      { name: "Encephalitis / meningitis (WNV/JEV)", severity: "critical" },
      { name: "Microcephaly (ZIKV, congenital)", severity: "critical" },
      { name: "Thrombocytopenia", severity: "severe" },
    ],
    transmission: ["Aedes/Culex mosquito bite (arboviruses)", "Bloodborne (HCV)", "Sexual (ZIKV)", "Perinatal (ZIKV/HCV)"],
    vaccines: [
      { name: "Dengvaxia (CYD-TDV)", platform: "Live attenuated chimeric", status: "licensed" },
      { name: "Qdenga (TAK-003)", platform: "Live attenuated chimeric (DEN2 backbone)", status: "licensed" },
      { name: "YF-VAX (17D strain)", platform: "Live attenuated", status: "licensed" },
      { name: "Imojev / JE-CV (JEV)", platform: "Chimeric live attenuated", status: "licensed" },
      { name: "ZIKA mRNA candidates", platform: "mRNA", status: "clinical_trial" },
    ],
    treatments: [
      { name: "Sofosbuvir + Ledipasvir (Harvoni)", type: "NS5B/NS5A inhibitor (HCV cure)" },
      { name: "Glecaprevir + Pibrentasvir (Mavyret)", type: "Pan-genotypic DAA (HCV)" },
      { name: "Supportive care (dengue/Zika)", type: "IV fluids, monitoring" },
    ],
    incubation: "2–15 days",
    cfr: "0.02–50% (Yellow fever highest untreated)",
    pandemicPotential: "high",
    organSystems: ["Hepatic", "Neurological", "Hematopoietic", "Reproductive (ZIKV)"],
    confidence: 89,
  },

  Paramyxoviridae: {
    family: "Paramyxoviridae",
    symptoms: [
      { name: "Fever & influenza-like illness", severity: "moderate" },
      { name: "Encephalitis (Nipah/Hendra)", severity: "critical" },
      { name: "Respiratory distress", severity: "severe" },
      { name: "Measles rash (koplik spots)", severity: "moderate" },
      { name: "Immune amnesia (measles)", severity: "severe" },
      { name: "Parotitis & orchitis (mumps)", severity: "moderate" },
      { name: "Seizures & coma (Nipah)", severity: "critical" },
    ],
    transmission: ["Airborne (measles/mumps)", "Bat contact (Nipah/Hendra)", "Horse-to-human (Hendra)", "Close respiratory droplets"],
    vaccines: [
      { name: "MMR / MMRV (measles component)", platform: "Live attenuated", status: "licensed" },
      { name: "HeV-sG equine vaccine (Equivac HeV)", platform: "Recombinant subunit", status: "licensed" },
      { name: "Nipah subunit vaccine candidates (G protein)", platform: "Recombinant protein", status: "clinical_trial" },
    ],
    treatments: [
      { name: "Ribavirin (Nipah supportive)", type: "Nucleoside analog (limited efficacy)" },
      { name: "m102.4 monoclonal antibody (Nipah/Hendra)", type: "Neutralizing antibody" },
      { name: "Supportive ICU care", type: "Intensive care" },
    ],
    incubation: "4–45 days (Nipah can be extended)",
    cfr: "0.1–75% (Nipah highest)",
    pandemicPotential: "high",
    organSystems: ["Neurological", "Respiratory", "Lymphatic"],
    confidence: 88,
  },

  Poxviridae: {
    family: "Poxviridae",
    symptoms: [
      { name: "Prodromal fever & malaise", severity: "moderate" },
      { name: "Characteristic pustular rash", severity: "severe" },
      { name: "Painful lymphadenopathy", severity: "moderate" },
      { name: "Lesions on face/trunk/extremities", severity: "severe" },
      { name: "Secondary bacterial infection", severity: "moderate" },
      { name: "Hemorrhagic pox (variola hemorrhagica)", severity: "critical" },
      { name: "Encephalitis (rare)", severity: "critical" },
    ],
    transmission: ["Direct skin-to-skin contact", "Respiratory large droplets (smallpox)", "Animal bite/scratch (mpox)", "Contaminated fomites"],
    vaccines: [
      { name: "JYNNEOS / Imvamune / Imvanex", platform: "Modified vaccinia Ankara (MVA)", status: "licensed" },
      { name: "ACAM2000", platform: "Replication-competent vaccinia", status: "licensed" },
      { name: "LC16m8 (Japan)", platform: "Attenuated vaccinia", status: "licensed" },
    ],
    treatments: [
      { name: "Tecovirimat (TPOXX/ST-246)", type: "VP37 envelope protein inhibitor" },
      { name: "Cidofovir (Vistide)", type: "DNA polymerase inhibitor" },
      { name: "Brincidofovir (Tembexa)", type: "Lipid-conjugated cidofovir prodrug" },
      { name: "Vaccinia immune globulin (VIG)", type: "Passive immunotherapy" },
    ],
    incubation: "5–21 days",
    cfr: "0–30% (mpox clade Ia ~10%)",
    pandemicPotential: "moderate",
    organSystems: ["Dermatological", "Lymphatic", "Respiratory", "Neurological"],
    confidence: 93,
  },

  Herpesviridae: {
    family: "Herpesviridae",
    symptoms: [
      { name: "Orolabial vesicular lesions (HSV-1)", severity: "mild" },
      { name: "Genital ulcerations (HSV-2)", severity: "moderate" },
      { name: "Varicella / chickenpox rash (VZV)", severity: "moderate" },
      { name: "Painful dermatomal shingles (VZV)", severity: "moderate" },
      { name: "Infectious mononucleosis (EBV)", severity: "moderate" },
      { name: "Congenital defects / deafness (CMV)", severity: "severe" },
      { name: "Encephalitis (HSV-1 CNS)", severity: "critical" },
      { name: "Lymphoma association (EBV)", severity: "severe" },
    ],
    transmission: ["Oral contact (HSV-1)", "Sexual contact (HSV-2/CMV)", "Respiratory (VZV)", "Congenital vertical (CMV)"],
    vaccines: [
      { name: "Shingrix (HZ/su)", platform: "Recombinant gE + AS01B adjuvant (VZV)", status: "licensed" },
      { name: "Varivax / Varilrix", platform: "Live attenuated VZV", status: "licensed" },
      { name: "EBV vaccine candidates (gH/gL/gp42)", platform: "Subunit protein", status: "clinical_trial" },
      { name: "CMV mRNA vaccine (mRNA-1647)", platform: "mRNA pentamer complex", status: "clinical_trial" },
    ],
    treatments: [
      { name: "Acyclovir / Valacyclovir", type: "Nucleoside analog (HSV/VZV)" },
      { name: "Ganciclovir / Valganciclovir", type: "Nucleoside analog (CMV)" },
      { name: "Foscarnet", type: "DNA polymerase inhibitor (resistant strains)" },
    ],
    incubation: "2–14 days (primary); reactivation variable",
    cfr: "<1% immunocompetent; high in encephalitis",
    pandemicPotential: "low",
    organSystems: ["Neurological", "Dermatological", "Hepatic", "Lymphatic", "Ophthalmological"],
    confidence: 95,
  },

  Rhabdoviridae: {
    family: "Rhabdoviridae",
    symptoms: [
      { name: "Prodromal fever, headache, malaise", severity: "moderate" },
      { name: "Pain/paresthesia at bite site", severity: "moderate" },
      { name: "Hydrophobia / aerophobia", severity: "severe" },
      { name: "Agitation & encephalitis", severity: "critical" },
      { name: "Progressive paralysis", severity: "critical" },
      { name: "Coma & respiratory failure", severity: "critical" },
    ],
    transmission: ["Animal bite (dogs/bats/raccoons)", "Scratch with infected saliva", "Rare: mucosal exposure"],
    vaccines: [
      { name: "RabAvert (PCECV)", platform: "Purified chick embryo cell vaccine", status: "licensed" },
      { name: "Imovax Rabies (HDCV)", platform: "Human diploid cell vaccine", status: "licensed" },
      { name: "Post-exposure prophylaxis (PEP) + RIG", platform: "Vaccine + passive immunoglobulin", status: "licensed" },
    ],
    treatments: [
      { name: "PEP vaccine series + RIG", type: "Only effective before symptom onset" },
      { name: "Milwaukee protocol (experimental)", type: "Ketamine-induced coma (rare success)" },
      { name: "Supportive ICU care", type: "Palliative once symptomatic" },
    ],
    incubation: "1–3 months (variable 4 days–19 years)",
    cfr: "~100% once symptomatic without PEP",
    pandemicPotential: "low",
    organSystems: ["Neurological", "Autonomic nervous system"],
    confidence: 97,
  },

  Hantaviridae: {
    family: "Hantaviridae",
    symptoms: [
      { name: "Fever, headache, malaise", severity: "moderate" },
      { name: "Hemorrhagic manifestations (HFRS)", severity: "severe" },
      { name: "Acute kidney injury / oliguria", severity: "severe" },
      { name: "Non-cardiogenic pulmonary edema (HPS)", severity: "critical" },
      { name: "Thrombocytopenia & coagulopathy", severity: "severe" },
    ],
    transmission: ["Inhalation of rodent excreta aerosols (primary)", "Rodent bite", "Contact with contaminated surfaces"],
    vaccines: [
      { name: "Hantavax (Hantaan)", platform: "Inactivated mouse brain (South Korea)", status: "licensed" },
      { name: "DNA & mRNA Hantavirus candidates", platform: "Nucleic acid vaccines", status: "research" },
    ],
    treatments: [
      { name: "Ribavirin (HFRS, early)", type: "Nucleoside analog" },
      { name: "Supportive care / dialysis", type: "Renal replacement" },
      { name: "ECMO (HPS)", type: "Extracorporeal membrane oxygenation" },
    ],
    incubation: "1–8 weeks",
    cfr: "1–40% (SNV pulmonary ~35%)",
    pandemicPotential: "low",
    organSystems: ["Renal", "Hematopoietic", "Pulmonary", "Cardiovascular"],
    confidence: 86,
  },

  Arenaviridae: {
    family: "Arenaviridae",
    symptoms: [
      { name: "Gradual onset fever & malaise", severity: "moderate" },
      { name: "Pharyngitis & chest pain", severity: "moderate" },
      { name: "Hemorrhagic manifestations", severity: "severe" },
      { name: "Neurological signs (tremors, encephalopathy)", severity: "severe" },
      { name: "Facial edema & bleeding gums", severity: "severe" },
      { name: "Spontaneous abortion (Lassa, pregnant)", severity: "critical" },
    ],
    transmission: ["Inhalation/ingestion of rodent excreta", "Direct contact with infected person (Lassa)", "Nosocomial spread"],
    vaccines: [
      { name: "Candid#1 (Argentine HF / Junin)", platform: "Live attenuated", status: "licensed" },
      { name: "Lassa vaccine candidates (MV-LASV/mRNA)", platform: "Multiple platforms", status: "clinical_trial" },
    ],
    treatments: [
      { name: "Ribavirin (Lassa fever)", type: "Nucleoside analog (best if early)" },
      { name: "Favipiravir (Lassa, experimental)", type: "RNA polymerase inhibitor" },
      { name: "Convalescent plasma (Junin AHF)", type: "Passive immunotherapy" },
    ],
    incubation: "6–21 days",
    cfr: "1–30% (Lassa varies widely)",
    pandemicPotential: "moderate",
    organSystems: ["Hepatic", "Neurological", "Hematopoietic", "Reproductive"],
    confidence: 87,
  },
};

const KEYWORD_TO_FAMILY: Array<{ pattern: RegExp; family: string }> = [
  { pattern: /coronavirus|sars|mers|covid|betacoronavirus|alphacoronavirus/i, family: "Coronaviridae" },
  { pattern: /ebola|marburg|filovir|hemorrhagic fever virus/i, family: "Filoviridae" },
  { pattern: /influenza|orthomyxo|H5N1|H1N1|H3N2/i, family: "Orthomyxoviridae" },
  { pattern: /HIV|human immunodeficiency|retrovir|lentivirus/i, family: "Retroviridae" },
  { pattern: /dengue|zika|west nile|yellow fever|hepatitis C|flavivir/i, family: "Flaviviridae" },
  { pattern: /nipah|hendra|measles|mumps|paramyxo|morbillivirus/i, family: "Paramyxoviridae" },
  { pattern: /pox|vaccinia|monkeypox|variola|smallpox/i, family: "Poxviridae" },
  { pattern: /herpes|herpesvir|cytomegalovirus|varicella|epstein/i, family: "Herpesviridae" },
  { pattern: /rabies|rhabdovir|lyssavir/i, family: "Rhabdoviridae" },
  { pattern: /hantavirus|hantaan|sin nombre|puumala/i, family: "Hantaviridae" },
  { pattern: /lassa|junin|machupo|arenavirida/i, family: "Arenaviridae" },
];

export function inferClinicalProfile(hitTitles: string[]): { profile: ClinicalProfile | null; matchedFamily: string; titleScores: Array<{ title: string; family: string }> } {
  const familyVotes: Record<string, number> = {};
  const titleScores: Array<{ title: string; family: string }> = [];

  for (const title of hitTitles.slice(0, 20)) {
    for (const { pattern, family } of KEYWORD_TO_FAMILY) {
      if (pattern.test(title)) {
        familyVotes[family] = (familyVotes[family] || 0) + 1;
        titleScores.push({ title: title.slice(0, 60), family });
        break;
      }
    }
  }

  if (Object.keys(familyVotes).length === 0) return { profile: null, matchedFamily: "Unknown", titleScores };

  const topFamily = Object.entries(familyVotes).sort((a, b) => b[1] - a[1])[0][0];
  return { profile: FAMILY_PROFILES[topFamily] ?? null, matchedFamily: topFamily, titleScores };
}

export function getPandemicScore(profile: ClinicalProfile | null): number {
  if (!profile) return 10;
  const map = { low: 20, moderate: 45, high: 72, very_high: 91 };
  return map[profile.pandemicPotential];
}

export { FAMILY_PROFILES };
