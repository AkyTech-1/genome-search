const CODON_TABLE: Record<string, string> = {
  TTT:"F",TTC:"F",TTA:"L",TTG:"L",CTT:"L",CTC:"L",CTA:"L",CTG:"L",
  ATT:"I",ATC:"I",ATA:"I",ATG:"M",GTT:"V",GTC:"V",GTA:"V",GTG:"V",
  TCT:"S",TCC:"S",TCA:"S",TCG:"S",CCT:"P",CCC:"P",CCA:"P",CCG:"P",
  ACT:"T",ACC:"T",ACA:"T",ACG:"T",GCT:"A",GCC:"A",GCA:"A",GCG:"A",
  TAT:"Y",TAC:"Y",TAA:"*",TAG:"*",CAT:"H",CAC:"H",CAA:"Q",CAG:"Q",
  AAT:"N",AAC:"N",AAA:"K",AAG:"K",GAT:"D",GAC:"D",GAA:"E",GAG:"E",
  TGT:"C",TGC:"C",TGA:"*",TGG:"W",CGT:"R",CGC:"R",CGA:"R",CGG:"R",
  AGT:"S",AGC:"S",AGA:"R",AGG:"R",GGT:"G",GGC:"G",GGA:"G",GGG:"G",
};

export interface ORFHit {
  start: number;
  end: number;
  frame: number;
  lengthAA: number;
  aa: string;
}

export interface SequenceStats {
  length: number;
  composition: { A: number; T: number; G: number; C: number; N: number };
  gcContent: number;
  atContent: number;
  purineContent: number;
  pyrimidineContent: number;
  cpgOE: number;
  entropy: number;
  complexity: number;
  longestHomopolymer: { base: string; length: number };
  topTrimers: Array<{ kmer: string; count: number; pct: number }>;
  orfs: ORFHit[];
  frameTranslation: string;
  codonUsage: Array<{ codon: string; aa: string; count: number; pct: number }>;
  signalPeptideScore: number;
  repeatFraction: number;
  dinucleotideZScore: Record<string, number>;
}

export function analyzeSequence(rawSeq: string): SequenceStats {
  const seq = rawSeq.replace(/\s/g, "").toUpperCase();
  const n = seq.length;
  if (n === 0) throw new Error("Empty sequence");

  // ── Composition ────────────────────────────────────────────────────────────
  const comp = { A: 0, T: 0, G: 0, C: 0, N: 0 };
  for (const b of seq) {
    if (b in comp) comp[b as keyof typeof comp]++;
    else comp.N++;
  }
  const gcContent = ((comp.G + comp.C) / n) * 100;
  const atContent = ((comp.A + comp.T) / n) * 100;
  const purineContent = ((comp.A + comp.G) / n) * 100;
  const pyrimidineContent = ((comp.C + comp.T) / n) * 100;

  // ── CpG O/E ────────────────────────────────────────────────────────────────
  let cpgObs = 0;
  for (let i = 0; i < n - 1; i++) if (seq[i] === "C" && seq[i + 1] === "G") cpgObs++;
  const cpgExpected = ((comp.C / n) * (comp.G / n)) * n;
  const cpgOE = cpgExpected > 0 ? cpgObs / cpgExpected : 0;

  // ── Shannon Entropy ─────────────────────────────────────────────────────────
  const freqs = [comp.A / n, comp.T / n, comp.G / n, comp.C / n].filter(f => f > 0);
  const entropy = -freqs.reduce((s, f) => s + f * Math.log2(f), 0);

  // ── Linguistic Complexity (unique k-mers / theoretical max) ────────────────
  const uniqueTrimer = new Set<string>();
  for (let i = 0; i <= n - 3; i++) uniqueTrimer.add(seq.slice(i, i + 3));
  const maxTrimers = Math.min(64, n - 2);
  const complexity = maxTrimers > 0 ? uniqueTrimer.size / maxTrimers : 0;

  // ── Longest Homopolymer ─────────────────────────────────────────────────────
  let longest = { base: seq[0], length: 1 };
  let cur = { base: seq[0], length: 1 };
  for (let i = 1; i < n; i++) {
    if (seq[i] === cur.base) { cur.length++; if (cur.length > longest.length) longest = { ...cur }; }
    else cur = { base: seq[i], length: 1 };
  }

  // ── Top 3-mers ──────────────────────────────────────────────────────────────
  const trimerCounts: Record<string, number> = {};
  for (let i = 0; i <= n - 3; i++) {
    const t = seq.slice(i, i + 3);
    if (/^[ATGC]+$/.test(t)) trimerCounts[t] = (trimerCounts[t] || 0) + 1;
  }
  const totalTrimers = n - 2;
  const topTrimers = Object.entries(trimerCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([kmer, count]) => ({ kmer, count, pct: (count / totalTrimers) * 100 }));

  // ── ORF Detection (all three forward frames, min 30aa) ─────────────────────
  const orfs: ORFHit[] = [];
  for (let frame = 0; frame < 3; frame++) {
    let start = -1;
    let aaSeq = "";
    for (let i = frame; i <= n - 3; i += 3) {
      const codon = seq.slice(i, i + 3);
      const aa = CODON_TABLE[codon] ?? "X";
      if (aa === "M" && start === -1) { start = i; aaSeq = "M"; }
      else if (start !== -1) {
        if (aa === "*") {
          const lenAA = aaSeq.length;
          if (lenAA >= 30) orfs.push({ start, end: i + 3, frame, lengthAA: lenAA, aa: aaSeq.slice(0, 25) + (lenAA > 25 ? "…" : "") });
          start = -1; aaSeq = "";
        } else { aaSeq += aa; }
      }
    }
    if (start !== -1 && aaSeq.length >= 30)
      orfs.push({ start, end: n, frame, lengthAA: aaSeq.length, aa: aaSeq.slice(0, 25) + "…" });
  }
  orfs.sort((a, b) => b.lengthAA - a.lengthAA);

  // ── Frame +1 Translation (first 80 codons) ──────────────────────────────────
  let frameTranslation = "";
  for (let i = 0; i <= Math.min(n - 3, 240); i += 3) {
    const codon = seq.slice(i, i + 3);
    frameTranslation += CODON_TABLE[codon] ?? "X";
  }

  // ── Codon Usage ────────────────────────────────────────────────────────────
  const codonCounts: Record<string, number> = {};
  let totalCodons = 0;
  for (let i = 0; i <= n - 3; i += 3) {
    const c = seq.slice(i, i + 3);
    if (/^[ATGC]{3}$/.test(c)) { codonCounts[c] = (codonCounts[c] || 0) + 1; totalCodons++; }
  }
  const codonUsage = Object.entries(codonCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 12)
    .map(([codon, count]) => ({ codon, aa: CODON_TABLE[codon] ?? "?", count, pct: (count / totalCodons) * 100 }));

  // ── Signal Peptide Score (crude: high hydrophobicity in first 30aa) ─────────
  const HYDROPHOBIC = new Set(["L","I","V","F","M","W","A","P"]);
  let hydCount = 0;
  for (let i = 0; i < Math.min(frameTranslation.length, 30); i++) {
    if (HYDROPHOBIC.has(frameTranslation[i])) hydCount++;
  }
  const signalPeptideScore = Math.min(1, hydCount / 12);

  // ── Repeat Fraction (simple: count tri-mers with >3x expected freq) ─────────
  const expectedTrimerFreq = 1 / 64;
  let repeatBases = 0;
  for (const [, count] of Object.entries(trimerCounts)) {
    const obs = count / totalTrimers;
    if (obs > expectedTrimerFreq * 4) repeatBases += count * 3;
  }
  const repeatFraction = Math.min(1, repeatBases / n);

  // ── Dinucleotide Z-scores ──────────────────────────────────────────────────
  const dinucleotideZScore: Record<string, number> = {};
  const DINUCS = ["CG","GC","AT","TA","AC","CA","AG","GA","TC","CT","TG","GT","AA","TT","GG","CC"];
  for (const dn of DINUCS) {
    let obs = 0;
    for (let i = 0; i < n - 1; i++) if (seq[i] === dn[0] && seq[i+1] === dn[1]) obs++;
    const pa = comp[dn[0] as keyof typeof comp] / n;
    const pb = comp[dn[1] as keyof typeof comp] / n;
    const exp = pa * pb * (n - 1);
    const variance = exp * (1 - pa * pb);
    const z = variance > 0 ? (obs - exp) / Math.sqrt(variance) : 0;
    dinucleotideZScore[dn] = Math.round(z * 10) / 10;
  }

  return {
    length: n, composition: comp, gcContent, atContent, purineContent, pyrimidineContent,
    cpgOE, entropy, complexity, longestHomopolymer: longest,
    topTrimers, orfs, frameTranslation, codonUsage, signalPeptideScore, repeatFraction,
    dinucleotideZScore,
  };
}

export function simpleIdentity(seqA: string, seqB: string): number {
  const a = seqA.replace(/\s/g, "").toUpperCase();
  const b = seqB.replace(/\s/g, "").toUpperCase();
  const len = Math.min(a.length, b.length, 120);
  if (len === 0) return 0;
  let matches = 0;
  for (let i = 0; i < len; i++) if (a[i] === b[i]) matches++;
  return Math.round((matches / len) * 100);
}
