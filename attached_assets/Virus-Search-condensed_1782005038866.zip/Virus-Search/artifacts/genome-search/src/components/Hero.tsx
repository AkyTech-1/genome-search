import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

function TypewriterText({ text, delay = 0, className = "" }: { text: string; delay?: number; className?: string }) {
  const [displayedText, setDisplayedText] = useState("");
  const [started, setStarted] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setStarted(true), delay);
    return () => clearTimeout(t);
  }, [delay]);

  useEffect(() => {
    if (!started) return;
    let i = 0;
    setDisplayedText("");
    const interval = setInterval(() => {
      if (i < text.length) {
        setDisplayedText(text.slice(0, i + 1));
        i++;
      } else {
        clearInterval(interval);
        setDone(true);
      }
    }, 38);
    return () => clearInterval(interval);
  }, [text, started]);

  return (
    <span className={`relative ${className}`} style={{
      backgroundImage: "linear-gradient(90deg, #22d3ee 0%, #a855f7 45%, #4ade80 100%)",
      WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
    }}>
      {displayedText || "\u00a0"}
      {!done && (
        <motion.span
          animate={{ opacity: [1, 1, 0, 0] }}
          transition={{ repeat: Infinity, duration: 0.7, times: [0, 0.49, 0.5, 1] }}
          className="inline-block w-[4px] h-[0.85em] bg-cyan-400 align-middle ml-1 rounded-sm"
          style={{ WebkitTextFillColor: "initial", backgroundClip: "initial", boxShadow: "0 0 8px #00e5ff" }}
        />
      )}
    </span>
  );
}

const LIVE_METRICS = [
  "GENOME_DB_STATUS......... ONLINE",
  "SEQUENCES_INDEXED........ 2,847,291",
  "LAST_SYNC................ 00:00:03",
  "BLAST_NODES.............. 8/8 ACTIVE",
  "THREAT_LEVEL............. ELEVATED",
  "BSL4_MONITORING.......... ACTIVE",
  "MUTATION_TRACKER......... RUNNING",
  "PHYLOGENY_ENGINE......... READY",
  "OUTBREAK_ALERT........... NONE",
  "GLOBAL_SURVEILLANCE...... ONLINE",
  "VARIANT_CALLS............ 14,302",
  "SEQUENCE_QUALITY......... 99.7%",
  "API_LATENCY.............. 12ms",
  "NCBI_LINK................ LIVE",
];

const THREAT_FEEDS = [
  { label: "H5N1 ACTIVITY", level: 78, color: "#ef4444" },
  { label: "MPOX VARIANT", level: 45, color: "#f97316" },
  { label: "SARS-CoV-3?", level: 22, color: "#f59e0b" },
  { label: "DENGUE SURGE", level: 61, color: "#f97316" },
  { label: "EBOLA WATCH", level: 33, color: "#a855f7" },
];

export function Hero() {
  const [metricIdx, setMetricIdx] = useState(0);
  const particles = useRef(
    Array.from({ length: 60 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      top: Math.random() * 100,
      duration: Math.random() * 15 + 8,
      delay: Math.random() * 8,
      size: Math.random() > 0.85 ? 3 : Math.random() > 0.6 ? 2 : 1,
      color: i % 3 === 0 ? "#00e5ff" : i % 3 === 1 ? "#b388ff" : "#4ade80",
    }))
  ).current;

  useEffect(() => {
    const t = setInterval(() => setMetricIdx(i => (i + 1) % LIVE_METRICS.length), 1400);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="relative w-full h-[80vh] min-h-[560px] flex items-center justify-center overflow-hidden bg-background border-b border-border/60">

      {/* ── Aurora blobs ── */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-[800px] h-[800px] rounded-full blur-[140px] animate-aurora"
          style={{ background: "radial-gradient(circle, rgba(0,229,255,0.22) 0%, rgba(0,229,255,0.06) 60%, transparent 100%)", top: "10%", left: "-5%" }} />
        <div className="absolute w-[700px] h-[700px] rounded-full blur-[160px] animate-aurora2"
          style={{ background: "radial-gradient(circle, rgba(168,85,247,0.20) 0%, rgba(168,85,247,0.05) 60%, transparent 100%)", bottom: "-10%", right: "0%" }} />
        <div className="absolute w-[500px] h-[500px] rounded-full blur-[120px]"
          style={{ background: "radial-gradient(circle, rgba(74,222,128,0.12) 0%, transparent 70%)", top: "30%", right: "15%", animation: "aurora 26s ease-in-out infinite reverse" }} />
      </div>

      {/* ── Rotating biohazard watermark ── */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden" style={{ opacity: 0.022 }}>
        <div className="text-[700px] leading-none animate-rotate-slow select-none" style={{ color: "hsl(var(--primary))" }}>☣</div>
      </div>

      {/* ── DNA Helix ── */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none flex justify-center" style={{ opacity: 0.22 }}>
        <svg viewBox="0 0 140 3200" className="animate-dna-scroll"
          style={{ height: "400%", width: "auto", minWidth: 80 }} preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 160 }).map((_, i) => {
            const phase = i * 0.42;
            const cx1 = 70 + Math.sin(phase) * 45;
            const cx2 = 70 + Math.sin(phase + Math.PI) * 45;
            const cy = i * 20;
            const opacity = 0.4 + 0.6 * Math.abs(Math.sin(phase));
            return (
              <g key={i}>
                <circle cx={cx1} cy={cy} r="3" fill="#00e5ff" opacity={opacity} />
                <circle cx={cx2} cy={cy} r="3" fill="#4ade80" opacity={opacity} />
                {i % 2 === 0 && <line x1={cx1} y1={cy} x2={cx2} y2={cy} stroke="#b388ff" strokeWidth="1.5" opacity="0.45" />}
                {i % 4 === 0 && <circle cx={(cx1 + cx2) / 2} cy={cy} r="1.2" fill="#ffffff" opacity="0.3" />}
              </g>
            );
          })}
          {Array.from({ length: 160 }).map((_, i) => {
            const phase = i * 0.42;
            const cx1 = 70 + Math.sin(phase) * 45;
            const cx2 = 70 + Math.sin(phase + Math.PI) * 45;
            const cy = 3200 + i * 20;
            const opacity = 0.4 + 0.6 * Math.abs(Math.sin(phase));
            return (
              <g key={`d${i}`}>
                <circle cx={cx1} cy={cy} r="3" fill="#00e5ff" opacity={opacity} />
                <circle cx={cx2} cy={cy} r="3" fill="#4ade80" opacity={opacity} />
                {i % 2 === 0 && <line x1={cx1} y1={cy} x2={cx2} y2={cy} stroke="#b388ff" strokeWidth="1.5" opacity="0.45" />}
              </g>
            );
          })}
        </svg>
      </div>

      {/* ── Floating particles ── */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {particles.map((p) => (
          <motion.div key={p.id}
            className="absolute rounded-full"
            style={{ left: `${p.left}%`, top: `${p.top}%`, width: p.size * 3, height: p.size * 3, backgroundColor: p.color, filter: `blur(${p.size > 2 ? 1 : 0.5}px)`, opacity: 0 }}
            animate={{ y: [0, -(60 + p.size * 20), 0], opacity: [0, 0.7, 0] }}
            transition={{ duration: p.duration, repeat: Infinity, delay: p.delay, ease: "easeInOut" }}
          />
        ))}
      </div>

      {/* ── Scanline sweep ── */}
      <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent pointer-events-none z-20 animate-scanline"
        style={{ boxShadow: "0 0 20px #00e5ff, 0 0 40px #00e5ff" }} />

      {/* ── CRT scanline overlay ── */}
      <div className="absolute inset-0 pointer-events-none z-10" style={{
        backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(0,0,0,0.06) 3px, rgba(0,0,0,0.06) 4px)",
        backgroundSize: "100% 4px",
      }} />

      {/* ── Left data panel ── */}
      <div className="absolute left-4 top-1/2 -translate-y-1/2 hidden xl:flex flex-col gap-1.5 z-20 pointer-events-none" style={{ opacity: 0.55 }}>
        <p className="font-mono text-[9px] text-cyan-400 uppercase tracking-widest mb-2 border-b border-cyan-400/30 pb-1">SYSTEM STATUS</p>
        <AnimatePresence mode="wait">
          <motion.p key={metricIdx}
            initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 8 }}
            transition={{ duration: 0.3 }}
            className="font-mono text-[9px] text-cyan-300/80 whitespace-nowrap">
            {LIVE_METRICS[metricIdx]}
          </motion.p>
        </AnimatePresence>
        {LIVE_METRICS.slice(0, 6).map((m, i) => (
          <p key={i} className="font-mono text-[8px] text-slate-600 whitespace-nowrap">{m}</p>
        ))}
      </div>

      {/* ── Right threat panel ── */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 hidden xl:flex flex-col gap-3 z-20 pointer-events-none w-44" style={{ opacity: 0.6 }}>
        <p className="font-mono text-[9px] text-red-400 uppercase tracking-widest border-b border-red-500/30 pb-1">LIVE THREAT FEEDS</p>
        {THREAT_FEEDS.map((t) => (
          <div key={t.label} className="space-y-1">
            <div className="flex justify-between items-center">
              <span className="font-mono text-[8px] text-slate-400 uppercase tracking-wider">{t.label}</span>
              <span className="font-mono text-[8px] font-bold" style={{ color: t.color }}>{t.level}%</span>
            </div>
            <div className="h-[3px] bg-slate-800 rounded-full overflow-hidden">
              <motion.div className="h-full rounded-full" style={{ backgroundColor: t.color }}
                initial={{ width: 0 }} animate={{ width: `${t.level}%` }}
                transition={{ duration: 1.5, delay: 0.5, ease: "easeOut" }} />
            </div>
          </div>
        ))}
      </div>

      {/* ── Classified badge ── */}
      <div className="absolute top-5 right-5 xl:right-52 z-30 flex items-center gap-2 font-mono text-xs animate-blink" style={{ color: "#ef4444" }}>
        <div className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_10px_#ef4444]" />
        CLASSIFIED LEVEL: BSL-4
      </div>

      {/* ── Corner decorations ── */}
      {[
        "top-3 left-3 border-t border-l",
        "top-3 right-3 border-t border-r",
        "bottom-3 left-3 border-b border-l",
        "bottom-3 right-3 border-b border-r",
      ].map((cls, i) => (
        <div key={i} className={`absolute ${cls} w-6 h-6 border-cyan-400/40 pointer-events-none z-20`} />
      ))}

      {/* ── Main content ── */}
      <div className="z-20 text-center space-y-6 max-w-5xl px-8 relative">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}
          className="inline-flex items-center gap-3 px-5 py-2 rounded-full border font-mono text-xs uppercase tracking-[0.25em]"
          style={{ borderColor: "rgba(0,229,255,0.25)", backgroundColor: "rgba(0,229,255,0.07)", color: "#00e5ff" }}>
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-60" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400" />
          </span>
          Global Pathogen Surveillance Network
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="font-orbitron text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black tracking-tight leading-[1.0]"
          style={{ minHeight: "1.1em" }}
        >
          <TypewriterText text="Viral Genome Intelligence" delay={300} />
        </motion.h1>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, delay: 1.8 }}
          className="flex flex-col items-center gap-2">
          <p className="font-mono text-sm md:text-base tracking-[0.3em] uppercase"
            style={{ color: "rgba(148,163,184,0.7)" }}>
            Observatory for High-Consequence Pathogens
          </p>
          <div className="flex items-center gap-6 text-[10px] font-mono tracking-widest">
            {["NCBI BLAST INTEGRATED", "49 PATHOGENS", "10+ ANALYSIS LAYERS"].map((tag, i) => (
              <span key={i} className="flex items-center gap-1.5" style={{ color: "rgba(0,229,255,0.6)" }}>
                <span className="w-1 h-1 rounded-full bg-cyan-400/60" />
                {tag}
              </span>
            ))}
          </div>
        </motion.div>

        {/* Threat level bar */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 2.4 }}
          className="flex items-center justify-center gap-4">
          <span className="font-mono text-[10px] text-slate-500 uppercase tracking-widest">Global Threat Index</span>
          <div className="flex gap-1">
            {[
              { label: "LOW", color: "#4ade80", active: false },
              { label: "MOD", color: "#f59e0b", active: false },
              { label: "HIGH", color: "#f97316", active: true },
              { label: "CRIT", color: "#ef4444", active: false },
            ].map((seg) => (
              <div key={seg.label} className="flex flex-col items-center gap-1">
                <div className="w-10 h-2 rounded-sm" style={{
                  backgroundColor: seg.active ? seg.color : "rgba(255,255,255,0.07)",
                  boxShadow: seg.active ? `0 0 10px ${seg.color}` : "none",
                  animation: seg.active ? "threat-pulse 2s ease-in-out infinite" : "none",
                }} />
                <span className="font-mono text-[7px] uppercase tracking-wider" style={{ color: seg.active ? seg.color : "rgba(255,255,255,0.2)" }}>{seg.label}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* ── Bottom gradient ── */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-background to-transparent pointer-events-none z-10" />
    </div>
  );
}
