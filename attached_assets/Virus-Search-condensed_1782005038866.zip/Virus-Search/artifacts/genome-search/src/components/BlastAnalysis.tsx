import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertTriangle, Dna, ShieldAlert, Activity, Microscope, Brain,
  TrendingUp, Zap, ExternalLink, ChevronDown, ChevronUp, Info,
  FlaskConical, Syringe, Biohazard, BarChart3, GitBranch, Atom
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { analyzeSequence, simpleIdentity } from "@/lib/sequenceAnalysis";
import { inferClinicalProfile, getPandemicScore } from "@/lib/clinicalKnowledge";
import type { SequenceStats } from "@/lib/sequenceAnalysis";

interface Hit { accession: string; title: string; score: number; evalue: string; identity: number }

const REFERENCE_DB = [
  { name: "SARS-CoV-2", acc: "MN908947", seq: "ATGTTTGTTTTTCTTGTTTTATTGCCACTAGTCTCTAGTCAGTGTGTTAATCTTACAACCAGAACTCAATTACCCCCTGCATACACTAATTCTTTCACACGTGGTGTTTATTACC", family: "Coronaviridae" },
  { name: "SARS-CoV-1", acc: "AY278741", seq: "ATGTTTGTGTTCCTGGTCTTGCTGCCCCTGTCACTGGTGTACAATCTTACACCTCAGACTCAGATTCCCCCAGCATACACTAATTCTTTCACACATGGTGTTTATTACCC", family: "Coronaviridae" },
  { name: "MERS-CoV",   acc: "JX869059", seq: "ATGTTCGTTCTGATCTTGTTAACTGCCACGGCCACAAGCACAAATTTACACCTCAGACAAAAGTTCCCAAAGCATACAGTAATTCTTTCACATGTGGTTTCTACTACCA", family: "Coronaviridae" },
  { name: "Ebola Virus",acc: "AF086833", seq: "ATGGGTGTTACAGGAATATTGCAGTTACCTCGTGATGAAGCCAAGAATATCACCTTGGTTGAGAGACAGATTGATGATAATCAAAAAGAGATTGGAATCTTCAAGTTGAAAG", family: "Filoviridae" },
  { name: "HIV-1",      acc: "NC_001802", seq: "ATGGGTGCGAGAGCGTCAGTATTAAGCGGGGGAAAATTAGATGCATGGGAAAAAATTCGGTTAAGGCCAGGGGGAAAGAAAAAATATAAATTAAAACATATAGTATGGGCAAGC", family: "Retroviridae" },
  { name: "H5N1 Influenza", acc: "CY014659", seq: "ATGAAGGCAATACTAGTAGTTATGCTATATACATTCGCAAGCATGGCAATAGTCAAAAGCAATCGGGCAGATAATACTAATATTAGTTTCAGAGAATACAAATGCAGACAATCTTG", family: "Orthomyxoviridae" },
  { name: "Dengue 2",   acc: "NC_001474", seq: "ATGAATAACCAACGGAAAGGTGGGTCGATATTCAAGATTTCAGGAATCAATACCAACAGCAATAATGAATGGGAGTGTAGTGGAGTTGATAAACCAAGACATGATGGCAATCAA", family: "Flaviviridae" },
  { name: "Nipah Virus",acc: "AJ564623", seq: "ATGAAAGCAATCCTGTCTTTAAGCAGTGCCTCCAATCAGCCTCCCAAACCAAAGCAGACAAATCCAAAAACAGCCCTGCAAACCACAAGGAAGCAAAATCGACAGCTGTGG", family: "Paramyxoviridae" },
];

function RadialMeter({ value, max = 100, color = "#00e5ff", label, size = 100 }: { value: number; max?: number; color?: string; label: string; size?: number }) {
  const pct = Math.min(1, value / max);
  const r = size * 0.38;
  const cx = size / 2;
  const circumference = 2 * Math.PI * r;
  const dash = pct * circumference * 0.75;
  const gap = circumference - dash;
  const rotation = -225;

  return (
    <div className="flex flex-col items-center gap-1">
      <div style={{ width: size, height: size }} className="relative">
        <svg width={size} height={size} className="rotate-0">
          <circle cx={cx} cy={cx} r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={size * 0.07}
            strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
            strokeDashoffset={0} transform={`rotate(${rotation} ${cx} ${cx})`} strokeLinecap="round" />
          <motion.circle cx={cx} cy={cx} r={r} fill="none" stroke={color} strokeWidth={size * 0.07}
            strokeDasharray={`${dash} ${gap + circumference * 0.25}`}
            strokeDashoffset={0} transform={`rotate(${rotation} ${cx} ${cx})`} strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 6px ${color})` }}
            initial={{ strokeDasharray: `0 ${circumference}` }}
            animate={{ strokeDasharray: `${dash} ${gap + circumference * 0.25}` }}
            transition={{ duration: 1.2, ease: "easeOut", delay: 0.3 }} />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-mono font-bold text-lg leading-none" style={{ color }}>{Math.round(value)}<span className="text-xs opacity-70">%</span></span>
        </div>
      </div>
      <span className="text-xs font-mono text-muted-foreground text-center leading-tight">{label}</span>
    </div>
  );
}

function HBar({ pct, color = "#00e5ff", label, value, max = 100 }: { pct: number; color?: string; label: string; value: string | number; max?: number }) {
  return (
    <div className="flex items-center gap-3 text-xs font-mono">
      <span className="w-20 text-right text-muted-foreground truncate shrink-0">{label}</span>
      <div className="flex-1 h-2 bg-background rounded-full overflow-hidden border border-border/50">
        <motion.div className="h-full rounded-full" style={{ backgroundColor: color, boxShadow: `0 0 6px ${color}` }}
          initial={{ width: 0 }} animate={{ width: `${Math.min(100, pct)}%` }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.1 }} />
      </div>
      <span className="w-14 text-right" style={{ color }}>{value}</span>
    </div>
  );
}

function SectionHeader({ icon: Icon, title, subtitle, color = "text-cyan-400" }: { icon: any; title: string; subtitle?: string; color?: string }) {
  return (
    <div className="flex items-start gap-3 mb-4">
      <div className={`p-2 rounded-lg bg-current/10 ${color} shrink-0`} style={{ background: "rgba(0,229,255,0.08)" }}>
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <div>
        <h3 className={`font-mono font-bold text-sm uppercase tracking-wider ${color}`}>{title}</h3>
        {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
      </div>
    </div>
  );
}

function Panel({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-card border border-border rounded-2xl p-5 shadow-[0_0_25px_rgba(0,0,0,0.4)] ${className}`}>
      {children}
    </div>
  );
}

export function BlastAnalysis({ hits, sequence }: { hits: Hit[]; sequence: string }) {
  const [showAllHits, setShowAllHits] = useState(false);
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  const stats: SequenceStats | null = useMemo(() => {
    try { return sequence.length >= 30 ? analyzeSequence(sequence) : null; } catch { return null; }
  }, [sequence]);

  const { profile, matchedFamily } = useMemo(() =>
    inferClinicalProfile(hits.map(h => h.title)), [hits]);

  const refComparisons = useMemo(() =>
    REFERENCE_DB.map(ref => ({
      ...ref,
      identity: simpleIdentity(sequence, ref.seq),
    })).sort((a, b) => b.identity - a.identity),
  [sequence]);

  const topHit = hits[0];
  const overallConfidence = topHit ? Math.round((topHit.identity * 0.6) + (Math.max(0, 40 - hits.filter(h => h.identity < 60).length) * 0.4)) : 0;
  const pandemicScore = getPandemicScore(profile);

  const familyCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const h of hits) {
      for (const ref of REFERENCE_DB) {
        if (h.title.toLowerCase().includes(ref.family.toLowerCase().split("idae")[0].toLowerCase())) {
          counts[ref.family] = (counts[ref.family] || 0) + 1;
        }
      }
    }
    if (Object.keys(counts).length === 0 && matchedFamily !== "Unknown") counts[matchedFamily] = hits.length;
    return counts;
  }, [hits, matchedFamily]);

  const visibleHits = showAllHits ? hits : hits.slice(0, 8);

  const SEVERITY_COLOR: Record<string, string> = {
    mild: "text-green-400 bg-green-500/10 border-green-500/30",
    moderate: "text-amber-400 bg-amber-500/10 border-amber-500/30",
    severe: "text-orange-400 bg-orange-500/10 border-orange-500/30",
    critical: "text-red-400 bg-red-500/10 border-red-500/30",
  };

  const STATUS_COLOR: Record<string, string> = {
    licensed: "text-green-400 bg-green-500/10 border-green-500/30",
    emergency: "text-amber-400 bg-amber-500/10 border-amber-500/30",
    clinical_trial: "text-blue-400 bg-blue-500/10 border-blue-500/30",
    research: "text-purple-400 bg-purple-500/10 border-purple-500/30",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6 mt-6"
    >
      {/* ── 1. INTELLIGENCE OVERVIEW ─────────────────────────────────────── */}
      <Panel>
        <SectionHeader icon={Brain} title="Intelligence Overview" subtitle="Top-level genomic threat assessment" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <RadialMeter value={overallConfidence} color="#00e5ff" label="Match Confidence" />
          <RadialMeter value={topHit?.identity ?? 0} color="#a855f7" label="Top Identity" />
          <RadialMeter value={pandemicScore} color={pandemicScore > 70 ? "#ef4444" : pandemicScore > 40 ? "#f97316" : "#22c55e"} label="Pandemic Potential" />
          <RadialMeter value={profile ? profile.confidence : 30} color="#4ade80" label="Clinical Inference" />
        </div>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
          <div className="bg-background/60 border border-border/50 rounded-xl p-3 space-y-1">
            <span className="text-muted-foreground uppercase tracking-wider block">Top Match</span>
            <span className="text-cyan-400 font-bold">{topHit?.title?.slice(0, 50) ?? "N/A"}…</span>
          </div>
          <div className="bg-background/60 border border-border/50 rounded-xl p-3 space-y-1">
            <span className="text-muted-foreground uppercase tracking-wider block">Inferred Family</span>
            <span className="text-purple-400 font-bold">{matchedFamily}</span>
          </div>
          <div className="bg-background/60 border border-border/50 rounded-xl p-3 space-y-1">
            <span className="text-muted-foreground uppercase tracking-wider block">BSL Inference</span>
            <span className={`font-bold ${profile?.pandemicPotential === "very_high" ? "text-red-400" : profile?.pandemicPotential === "high" ? "text-orange-400" : "text-amber-400"}`}>
              {profile?.pandemicPotential === "very_high" ? "BSL-3 / BSL-4 range" :
               profile?.pandemicPotential === "high" ? "BSL-3 range" :
               profile?.pandemicPotential === "moderate" ? "BSL-2/3 range" : "BSL-1/2 range"}
            </span>
          </div>
        </div>
      </Panel>

      {/* ── 2. SEQUENCE MATCH TABLE (show more) ─────────────────────────── */}
      <Panel>
        <SectionHeader icon={Microscope} title={`Sequence Match Report — ${hits.length} Hits`} subtitle="NCBI BLAST results ranked by identity" />
        {hits.length === 0 && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="mb-4 rounded-xl border border-amber-500/40 bg-amber-500/10 p-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-mono font-bold text-amber-300 uppercase tracking-wider mb-1">No Significant NCBI Matches Detected</p>
              <p className="text-xs text-amber-200/70 font-mono leading-relaxed">
                BLAST returned zero hits above threshold — this sequence has no close relatives in the NCBI nucleotide database.
                This is a strong indicator of a <span className="text-amber-300 font-bold">novel, synthetic, or highly divergent</span> sequence.
                All sequence intelligence panels below are derived directly from the raw nucleotide data and remain fully valid.
              </p>
            </div>
          </motion.div>
        )}
        <div className="overflow-x-auto rounded-xl border border-border/50">
          <table className="w-full text-xs font-mono">
            <thead>
              <tr className="border-b border-border bg-background/60">
                <th className="text-left p-2 text-muted-foreground uppercase tracking-wider">#</th>
                <th className="text-left p-2 text-muted-foreground uppercase tracking-wider">Accession</th>
                <th className="text-left p-2 text-muted-foreground uppercase tracking-wider">Organism</th>
                <th className="text-left p-2 text-muted-foreground uppercase tracking-wider w-28">Identity</th>
                <th className="text-right p-2 text-muted-foreground uppercase tracking-wider">E-value</th>
                <th className="text-right p-2 text-muted-foreground uppercase tracking-wider">Score</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence>
                {visibleHits.map((hit, i) => {
                  const isTop = hit.identity >= 95;
                  return (
                    <motion.tr key={i}
                      initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: Math.min(i, 8) * 0.04 }}
                      className="border-b border-border/30 hover:bg-cyan-400/5 transition-colors">
                      <td className="p-2 text-muted-foreground">{i + 1}</td>
                      <td className="p-2">
                        <a href={`https://www.ncbi.nlm.nih.gov/nuccore/${hit.accession}`} target="_blank" rel="noreferrer"
                          className="text-cyan-400 hover:underline flex items-center gap-1">
                          {hit.accession}<ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      </td>
                      <td className="p-2 max-w-[180px] truncate" title={hit.title}>
                        <span className={isTop ? "text-red-400 font-bold" : "text-foreground"}>{hit.title}</span>
                      </td>
                      <td className="p-2">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-1.5 bg-background rounded-full overflow-hidden">
                            <motion.div className="h-full rounded-full"
                              style={{ backgroundColor: isTop ? "#ef4444" : "#00e5ff", boxShadow: isTop ? "0 0 6px #ef4444" : "0 0 6px #00e5ff" }}
                              initial={{ width: 0 }} animate={{ width: `${hit.identity}%` }}
                              transition={{ delay: 0.3 + i * 0.03, duration: 0.7 }} />
                          </div>
                          <span className={isTop ? "text-red-400 font-bold w-10 text-right" : "text-foreground w-10 text-right"}>{hit.identity}%</span>
                        </div>
                      </td>
                      <td className="p-2 text-right text-muted-foreground">{hit.evalue}</td>
                      <td className="p-2 text-right text-muted-foreground">{hit.score}</td>
                    </motion.tr>
                  );
                })}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
        {hits.length > 8 && (
          <div className="mt-3 flex justify-center">
            <Button variant="outline" size="sm" onClick={() => setShowAllHits(v => !v)}
              className="font-mono text-xs border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 hover:border-cyan-500/60 gap-2">
              {showAllHits ? <><ChevronUp className="w-3.5 h-3.5" /> Show Less</> : <><ChevronDown className="w-3.5 h-3.5" /> Show All {hits.length} Matches</>}
            </Button>
          </div>
        )}
      </Panel>

      {/* ── 3. SEQUENCE DISSECTION ───────────────────────────────────────── */}
      {stats && (
        <Panel>
          <SectionHeader icon={Dna} title="Sequence Dissection" subtitle={`${stats.length} bp analyzed — deep nucleotide composition & structure`} color="text-green-400" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Composition */}
            <div className="space-y-2">
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-3">Nucleotide Composition</p>
              <HBar pct={(stats.composition.A / stats.length) * 100} color="#4ade80" label="Adenine (A)" value={`${((stats.composition.A / stats.length) * 100).toFixed(1)}%`} />
              <HBar pct={(stats.composition.T / stats.length) * 100} color="#ef4444" label="Thymine (T)" value={`${((stats.composition.T / stats.length) * 100).toFixed(1)}%`} />
              <HBar pct={(stats.composition.G / stats.length) * 100} color="#3b82f6" label="Guanine (G)" value={`${((stats.composition.G / stats.length) * 100).toFixed(1)}%`} />
              <HBar pct={(stats.composition.C / stats.length) * 100} color="#f59e0b" label="Cytosine (C)" value={`${((stats.composition.C / stats.length) * 100).toFixed(1)}%`} />
              <HBar pct={stats.gcContent} color="#a855f7" label="GC Content" value={`${stats.gcContent.toFixed(1)}%`} />
              <HBar pct={stats.purineContent} color="#06b6d4" label="Purine (A+G)" value={`${stats.purineContent.toFixed(1)}%`} />
            </div>
            {/* Biochemical metrics */}
            <div className="space-y-3">
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-3">Biochemical Metrics</p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: "GC Content", value: `${stats.gcContent.toFixed(1)}%`, interp: stats.gcContent < 35 ? "AT-rich" : stats.gcContent > 65 ? "GC-rich" : "Balanced", color: stats.gcContent > 50 ? "text-blue-400" : "text-green-400" },
                  { label: "Shannon Entropy", value: stats.entropy.toFixed(3), interp: stats.entropy > 1.9 ? "High complexity" : stats.entropy > 1.5 ? "Moderate" : "Low complexity", color: stats.entropy > 1.9 ? "text-cyan-400" : "text-amber-400" },
                  { label: "Seq. Complexity", value: `${(stats.complexity * 100).toFixed(0)}%`, interp: stats.complexity > 0.8 ? "Diverse" : stats.complexity > 0.5 ? "Moderate" : "Repetitive", color: stats.complexity > 0.7 ? "text-green-400" : "text-red-400" },
                  { label: "CpG O/E Ratio", value: stats.cpgOE.toFixed(2), interp: stats.cpgOE < 0.4 ? "CpG suppressed (mammalian)" : stats.cpgOE > 1.2 ? "CpG island" : "Normal", color: stats.cpgOE < 0.4 ? "text-amber-400" : "text-cyan-400" },
                  { label: "Longest Homopolymer", value: `${stats.longestHomopolymer.base}×${stats.longestHomopolymer.length}`, interp: stats.longestHomopolymer.length > 6 ? "Slippage risk" : "Normal", color: stats.longestHomopolymer.length > 6 ? "text-orange-400" : "text-green-400" },
                  { label: "Signal Peptide", value: `${(stats.signalPeptideScore * 100).toFixed(0)}%`, interp: stats.signalPeptideScore > 0.6 ? "Likely secreted" : "Cytoplasmic", color: stats.signalPeptideScore > 0.6 ? "text-purple-400" : "text-muted-foreground" },
                ].map(m => (
                  <div key={m.label} className="bg-background/60 border border-border/40 rounded-lg p-2 space-y-0.5">
                    <span className="text-[10px] text-muted-foreground uppercase tracking-wider block">{m.label}</span>
                    <span className={`text-sm font-mono font-bold ${m.color}`}>{m.value}</span>
                    <span className="text-[10px] text-muted-foreground block">{m.interp}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Panel>
      )}

      {/* ── 4. ORF MAP + CODON USAGE ─────────────────────────────────────── */}
      {stats && (
        <Panel>
          <SectionHeader icon={GitBranch} title="Open Reading Frames & Codon Usage" subtitle="Predicted protein-coding regions and codon bias analysis" color="text-blue-400" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-3">Detected ORFs (≥30 aa)</p>
              {stats.orfs.length > 0 ? (
                <div className="space-y-2">
                  {stats.orfs.slice(0, 5).map((orf, i) => (
                    <div key={i} className="bg-background/60 border border-border/40 rounded-lg p-2.5 flex gap-3 items-start">
                      <div className="shrink-0">
                        <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 border border-blue-500/30 rounded px-1.5 py-0.5">
                          +{orf.frame + 1}
                        </span>
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs font-mono text-foreground">{orf.start}..{orf.end}</span>
                          <span className="text-xs font-mono text-blue-400">{orf.lengthAA} aa</span>
                        </div>
                        <p className="text-[10px] font-mono text-muted-foreground break-all tracking-widest">{orf.aa}</p>
                      </div>
                    </div>
                  ))}
                  {stats.orfs.length === 0 && <p className="text-xs text-muted-foreground font-mono">No ORFs ≥30aa detected in forward frames</p>}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground font-mono bg-background/40 rounded-lg p-4 text-center">No significant ORFs detected — sequence may be non-coding or partial</p>
              )}
              {/* ORF visualization */}
              {stats.length > 0 && (
                <div className="mt-3">
                  <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-1.5">ORF Map (3 forward frames)</p>
                  {[0, 1, 2].map(frame => (
                    <div key={frame} className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-mono text-muted-foreground w-5">+{frame+1}</span>
                      <div className="flex-1 h-4 bg-background/60 border border-border/40 rounded-sm relative overflow-hidden">
                        {stats.orfs.filter(o => o.frame === frame).map((orf, i) => (
                          <motion.div key={i}
                            className="absolute top-0.5 bottom-0.5 rounded-sm bg-blue-500/60"
                            style={{ left: `${(orf.start / stats.length) * 100}%`, width: `${((orf.end - orf.start) / stats.length) * 100}%`, boxShadow: "0 0 4px #3b82f6" }}
                            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 + i * 0.1 }} />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div>
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-3">Top Codon Usage</p>
              <div className="space-y-1.5">
                {stats.codonUsage.slice(0, 10).map((c, i) => (
                  <div key={c.codon} className="flex items-center gap-2 text-xs font-mono">
                    <span className="w-8 text-blue-400">{c.codon}</span>
                    <span className="w-4 text-amber-400">{c.aa}</span>
                    <div className="flex-1 h-1.5 bg-background rounded-full overflow-hidden">
                      <motion.div className="h-full rounded-full bg-blue-400/80"
                        initial={{ width: 0 }} animate={{ width: `${(c.pct / (stats.codonUsage[0]?.pct ?? 1)) * 100}%` }}
                        transition={{ delay: 0.2 + i * 0.05, duration: 0.6 }} />
                    </div>
                    <span className="w-12 text-right text-muted-foreground">{c.pct.toFixed(1)}%</span>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-2">Frame +1 Translation (first 80 aa)</p>
                <div className="bg-black rounded-lg p-2.5 text-[10px] font-mono break-all text-green-400 leading-relaxed max-h-20 overflow-y-auto border border-border/40">
                  {stats.frameTranslation}
                </div>
              </div>
            </div>
          </div>
        </Panel>
      )}

      {/* ── 5. K-MER & DINUCLEOTIDE ANALYSIS ────────────────────────────── */}
      {stats && (
        <Panel>
          <SectionHeader icon={BarChart3} title="K-mer & Dinucleotide Bias Analysis" subtitle="Sequence composition patterns rarely shown elsewhere" color="text-amber-400" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-3">Top 3-mers (Trinucleotide Frequency)</p>
              <div className="space-y-1.5">
                {stats.topTrimers.slice(0, 8).map((t, i) => (
                  <HBar key={t.kmer} pct={(t.pct / (stats.topTrimers[0]?.pct ?? 1)) * 100}
                    color="#f59e0b" label={t.kmer} value={`${t.pct.toFixed(2)}%`} />
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-3">Dinucleotide Z-scores (deviation from expected)</p>
              <div className="grid grid-cols-4 gap-1.5">
                {Object.entries(stats.dinucleotideZScore)
                  .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
                  .slice(0, 8)
                  .map(([dn, z]) => (
                    <div key={dn} className={`rounded-lg border p-2 text-center text-xs font-mono ${
                      Math.abs(z) > 3 ? "border-red-500/40 bg-red-500/10" :
                      Math.abs(z) > 1.5 ? "border-amber-500/40 bg-amber-500/10" : "border-border/40 bg-background/60"
                    }`}>
                      <div className="font-bold text-sm">{dn}</div>
                      <div className={Math.abs(z) > 3 ? "text-red-400" : Math.abs(z) > 1.5 ? "text-amber-400" : "text-muted-foreground"}>
                        {z > 0 ? "+" : ""}{z}σ
                      </div>
                    </div>
                  ))}
              </div>
              <p className="text-[10px] text-muted-foreground mt-2 font-mono">
                {(stats.dinucleotideZScore["CG"] ?? 0) < -2 ? "⚠ Strong CpG suppression — consistent with mammalian adaptation." :
                 (stats.dinucleotideZScore["CG"] ?? 0) > 2 ? "✓ CpG-rich — possible CpG island or bacterial/insect origin." :
                 "CpG ratio within normal range for vertebrate-adapted viruses."}
              </p>
            </div>
          </div>
        </Panel>
      )}

      {/* ── 6. COMPARATIVE REFERENCE PANEL ──────────────────────────────── */}
      <Panel>
        <SectionHeader icon={Atom} title="Comparative Genomics — Reference Panel" subtitle="Identity against 8 characterized viral reference sequences" color="text-purple-400" />
        <div className="space-y-2">
          {refComparisons.map((ref, i) => (
            <motion.div key={ref.acc} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.07 }}
              className="flex items-center gap-3 text-xs font-mono bg-background/40 border border-border/40 rounded-xl p-3">
              <div className="w-36 shrink-0">
                <div className="font-bold text-foreground">{ref.name}</div>
                <div className="text-muted-foreground">{ref.family}</div>
              </div>
              <div className="flex-1 h-2.5 bg-background rounded-full overflow-hidden border border-border/30">
                <motion.div className="h-full rounded-full"
                  style={{
                    backgroundColor: ref.identity >= 80 ? "#ef4444" : ref.identity >= 50 ? "#a855f7" : ref.identity >= 25 ? "#00e5ff" : "#374151",
                    boxShadow: ref.identity >= 50 ? `0 0 8px ${ref.identity >= 80 ? "#ef4444" : "#a855f7"}` : "none"
                  }}
                  initial={{ width: 0 }} animate={{ width: `${ref.identity}%` }}
                  transition={{ delay: 0.3 + i * 0.07, duration: 0.8, ease: "easeOut" }} />
              </div>
              <span className={`w-14 text-right font-bold shrink-0 ${ref.identity >= 80 ? "text-red-400" : ref.identity >= 50 ? "text-purple-400" : ref.identity >= 25 ? "text-cyan-400" : "text-muted-foreground"}`}>
                {ref.identity}%
              </span>
              <a href={`https://www.ncbi.nlm.nih.gov/nuccore/${ref.acc}`} target="_blank" rel="noreferrer"
                className="text-muted-foreground hover:text-cyan-400 transition-colors shrink-0">
                <ExternalLink className="w-3 h-3" />
              </a>
            </motion.div>
          ))}
        </div>
        <div className="mt-3 flex gap-4 text-[10px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500 inline-block" /> ≥80% close relative</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-purple-500 inline-block" /> 50-79% related genus</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-cyan-500 inline-block" /> 25-49% distant family</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-gray-600 inline-block" /> &lt;25% unrelated</span>
        </div>
      </Panel>

      {/* ── 7. PHYLOGENETIC CLUSTERING ──────────────────────────────────── */}
      <Panel>
        <SectionHeader icon={TrendingUp} title="Phylogenetic Distribution" subtitle="Taxonomic breakdown of all matched sequences" color="text-cyan-400" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2 space-y-2">
            <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-3">Identity Distribution Across Hits</p>
            {[
              { label: "≥95% — Strain-level match", count: hits.filter(h => h.identity >= 95).length, color: "#ef4444" },
              { label: "80–94% — Species-level match", count: hits.filter(h => h.identity >= 80 && h.identity < 95).length, color: "#f97316" },
              { label: "60–79% — Genus-level match", count: hits.filter(h => h.identity >= 60 && h.identity < 80).length, color: "#a855f7" },
              { label: "40–59% — Family-level match", count: hits.filter(h => h.identity >= 40 && h.identity < 60).length, color: "#00e5ff" },
              { label: "<40% — Order/Class match", count: hits.filter(h => h.identity < 40).length, color: "#374151" },
            ].map(b => (
              <div key={b.label} className="flex items-center gap-3 text-xs font-mono">
                <div className="w-3 h-3 rounded-sm shrink-0" style={{ backgroundColor: b.color }} />
                <span className="text-muted-foreground flex-1">{b.label}</span>
                <div className="w-24 h-1.5 bg-background rounded-full overflow-hidden">
                  <motion.div className="h-full rounded-full" style={{ backgroundColor: b.color }}
                    initial={{ width: 0 }} animate={{ width: `${hits.length > 0 ? (b.count / hits.length) * 100 : 0}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }} />
                </div>
                <span style={{ color: b.color }} className="w-8 text-right font-bold">{b.count}</span>
              </div>
            ))}
          </div>
          <div className="space-y-2">
            <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-3">Score Statistics</p>
            {[
              { label: "Total Hits", value: hits.length, color: "text-cyan-400" },
              { label: "Avg Identity", value: hits.length > 0 ? `${Math.round(hits.reduce((s, h) => s + h.identity, 0) / hits.length)}%` : "N/A", color: "text-purple-400" },
              { label: "Best Score", value: hits[0]?.score ?? "—", color: "text-green-400" },
              { label: "Worst E-value", value: hits[hits.length - 1]?.evalue ?? "—", color: "text-amber-400" },
              { label: "Inferred Family", value: matchedFamily.replace(/idae$/, "…"), color: "text-red-400" },
            ].map(s => (
              <div key={s.label} className="flex justify-between items-center bg-background/50 border border-border/40 rounded-lg px-3 py-2 text-xs font-mono">
                <span className="text-muted-foreground">{s.label}</span>
                <span className={`font-bold ${s.color}`}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </Panel>

      {/* ── 8. MUTATION & DIVERGENCE ANALYSIS ───────────────────────────── */}
      {stats && (
        <Panel>
          <SectionHeader icon={Zap} title="Divergence & Novelty Analysis" subtitle="How different is this sequence from known references?" color="text-orange-400" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              {
                title: "Divergence from Top Hit",
                value: `${(100 - (topHit?.identity ?? 0)).toFixed(1)}%`,
                sub: topHit ? (topHit.identity >= 99 ? "Essentially identical — known strain" :
                  topHit.identity >= 95 ? "Minor variant — within strain range" :
                  topHit.identity >= 85 ? "Emerging variant — possible novel strain" :
                  topHit.identity >= 70 ? "Significant divergence — possible new species" :
                  "Highly divergent — potential new genus") : "N/A",
                color: (100 - (topHit?.identity ?? 100)) < 5 ? "#4ade80" : (100 - (topHit?.identity ?? 100)) < 15 ? "#f97316" : "#ef4444"
              },
              {
                title: "Estimated Substitutions",
                value: topHit ? `~${Math.round((100 - topHit.identity) / 100 * sequence.length)} nt` : "N/A",
                sub: "Approximate nucleotide substitutions vs. top hit",
                color: "#a855f7"
              },
              {
                title: "Novelty Risk Score",
                value: topHit ? (topHit.identity < 70 ? "HIGH" : topHit.identity < 90 ? "MODERATE" : "LOW") : "N/A",
                sub: topHit ? (topHit.identity < 70 ? "May represent undescribed pathogen" :
                  topHit.identity < 90 ? "Variant of known pathogen" :
                  "Known described strain") : "No hits",
                color: topHit ? (topHit.identity < 70 ? "#ef4444" : topHit.identity < 90 ? "#f97316" : "#4ade80") : "#374151"
              },
            ].map(card => (
              <div key={card.title} className="bg-background/60 border border-border/40 rounded-xl p-4 space-y-1.5">
                <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider">{card.title}</p>
                <p className="text-2xl font-mono font-bold" style={{ color: card.color }}>{card.value}</p>
                <p className="text-xs text-muted-foreground font-mono">{card.sub}</p>
              </div>
            ))}
          </div>
          {stats.complexity < 0.5 && (
            <div className="mt-3 flex items-start gap-2 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg text-xs font-mono text-amber-400">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              Low sequence complexity detected ({(stats.complexity * 100).toFixed(0)}%). Results may be inflated by repetitive elements. Consider masking low-complexity regions before interpreting BLAST scores.
            </div>
          )}
        </Panel>
      )}

      {/* ── 9. CLINICAL INTELLIGENCE ────────────────────────────────────── */}
      {profile && (
        <Panel>
          <div className="flex items-start gap-3 mb-4 p-4 bg-red-950/30 border border-red-500/30 rounded-xl">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="text-xs font-mono text-red-300 space-y-0.5">
              <p className="font-bold uppercase tracking-wider text-red-400">⚠ Medical Disclaimer — Not Clinical Advice</p>
              <p className="text-red-300/80">The following is algorithmically inferred from sequence homology to known pathogens. It is NOT a clinical diagnosis. Accuracy: ~{profile.confidence}%. Always consult qualified biosafety personnel and public health authorities for any actual pathogen identification.</p>
            </div>
          </div>

          <SectionHeader icon={FlaskConical} title={`Clinical Intelligence — Inferred: ${matchedFamily}`}
            subtitle={`${profile.confidence}% confidence based on sequence homology`} color="text-red-400" />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Symptoms */}
            <div>
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-3">Inferred Symptom Profile</p>
              <div className="space-y-1.5">
                {profile.symptoms.map(s => (
                  <div key={s.name} className={`flex items-center justify-between gap-2 px-3 py-1.5 rounded-lg border text-xs font-mono ${SEVERITY_COLOR[s.severity]}`}>
                    <span>{s.name}</span>
                    <span className="text-[10px] uppercase tracking-wider opacity-80">{s.severity}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              {/* Key clinical metrics */}
              <div>
                <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-2">Clinical Parameters</p>
                <div className="space-y-1.5">
                  {[
                    { label: "Incubation Period", value: profile.incubation },
                    { label: "Case Fatality Rate", value: profile.cfr },
                    { label: "Pandemic Potential", value: profile.pandemicPotential.replace("_", " ").toUpperCase() },
                    { label: "Organ Systems", value: profile.organSystems.join(", ") },
                  ].map(m => (
                    <div key={m.label} className="flex justify-between gap-3 bg-background/60 border border-border/40 rounded-lg px-3 py-2 text-xs font-mono">
                      <span className="text-muted-foreground shrink-0">{m.label}</span>
                      <span className="text-foreground text-right">{m.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Transmission */}
              <div>
                <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-2">Transmission Routes</p>
                <div className="flex flex-wrap gap-1.5">
                  {profile.transmission.map(t => (
                    <span key={t} className="px-2 py-1 bg-orange-500/10 border border-orange-500/30 text-orange-400 text-[10px] font-mono rounded-md">{t}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Vaccines */}
          <div className="mt-5">
            <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-3">
              <Syringe className="w-3.5 h-3.5 inline mr-1.5 mb-0.5" />
              Vaccine Approaches for {matchedFamily}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {profile.vaccines.map(v => (
                <div key={v.name} className="bg-background/60 border border-border/40 rounded-xl p-3 flex gap-3 items-start">
                  <div className="shrink-0 mt-0.5">
                    <Syringe className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-mono font-bold text-foreground">{v.name}</span>
                      <span className={`text-[10px] font-mono shrink-0 px-1.5 py-0.5 rounded border ${STATUS_COLOR[v.status]}`}>
                        {v.status.replace("_", " ")}
                      </span>
                    </div>
                    <p className="text-[10px] text-muted-foreground font-mono mt-0.5">{v.platform}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Treatments */}
          <div className="mt-4">
            <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-2">
              <FlaskConical className="w-3.5 h-3.5 inline mr-1.5 mb-0.5" />
              Treatment Approaches
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {profile.treatments.map(t => (
                <div key={t.name} className="flex gap-2 items-start bg-background/60 border border-border/40 rounded-lg px-3 py-2 text-xs font-mono">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                  <div>
                    <span className="font-bold text-cyan-400">{t.name}</span>
                    <span className="text-muted-foreground block text-[10px] mt-0.5">{t.type}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      )}

      {/* ── 10. BIOHAZARD RISK SUMMARY ───────────────────────────────────── */}
      <Panel className="border-red-500/20">
        <SectionHeader icon={ShieldAlert} title="Threat Assessment Summary" subtitle="Integrated risk scoring across all analysis modules" color="text-red-400" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Sequence Match Quality", score: overallConfidence, icon: Microscope },
            { label: "Genomic Novelty Risk", score: topHit ? Math.round(100 - topHit.identity) : 50, icon: Dna },
            { label: "Pandemic Potential", score: pandemicScore, icon: Activity },
            { label: "Clinical Severity Est.", score: profile ? { low: 20, moderate: 45, high: 70, very_high: 88 }[profile.pandemicPotential] : 30, icon: AlertTriangle },
          ].map(m => {
            const Icon = m.icon;
            const color = m.score > 70 ? "#ef4444" : m.score > 40 ? "#f97316" : "#4ade80";
            return (
              <div key={m.label} className="bg-background/60 border border-border/40 rounded-xl p-4 text-center space-y-2">
                <Icon className="w-5 h-5 mx-auto text-muted-foreground" />
                <div className="text-2xl font-mono font-bold" style={{ color }}>{m.score}%</div>
                <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider leading-tight">{m.label}</div>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-[10px] font-mono text-muted-foreground text-center">
          All scores are algorithmic estimates derived from sequence homology. This platform does not replace certified laboratory diagnostics or biosafety consultation.
        </p>
      </Panel>
    </motion.div>
  );
}
