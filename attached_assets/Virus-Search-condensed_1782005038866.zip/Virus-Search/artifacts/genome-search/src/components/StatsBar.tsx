import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Activity, ShieldAlert, Microscope, Dna, Wifi } from "lucide-react";
import type { Virus } from "@workspace/api-client-react";

function AnimatedCounter({ value, duration = 1200 }: { value: number; duration?: number }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (value === 0) { setCount(0); return; }
    let start: number | null = null;
    let frame: number;
    const step = (ts: number) => {
      if (!start) start = ts;
      const progress = Math.min((ts - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.round(eased * value));
      if (progress < 1) frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [value, duration]);

  return <>{count}</>;
}

const STAT_CONFIG = [
  {
    key: "total",
    label: "Total Pathogens",
    sublabel: "catalogued",
    icon: Dna,
    accent: "#00e5ff",
    shadow: "rgba(0,229,255,0.35)",
    bg: "rgba(0,229,255,0.06)",
    border: "rgba(0,229,255,0.15)",
    iconBg: "rgba(0,229,255,0.1)",
    hoverBorder: "rgba(0,229,255,0.5)",
  },
  {
    key: "bsl4",
    label: "BSL-4 Agents",
    sublabel: "maximum containment",
    icon: ShieldAlert,
    accent: "#ef4444",
    shadow: "rgba(239,68,68,0.4)",
    bg: "rgba(239,68,68,0.06)",
    border: "rgba(239,68,68,0.2)",
    iconBg: "rgba(239,68,68,0.12)",
    hoverBorder: "rgba(239,68,68,0.6)",
  },
  {
    key: "families",
    label: "Viral Families",
    sublabel: "taxonomic groups",
    icon: Microscope,
    accent: "#a855f7",
    shadow: "rgba(168,85,247,0.35)",
    bg: "rgba(168,85,247,0.06)",
    border: "rgba(168,85,247,0.15)",
    iconBg: "rgba(168,85,247,0.1)",
    hoverBorder: "rgba(168,85,247,0.5)",
  },
  {
    key: "emerging",
    label: "Emerging / Novel",
    sublabel: "active monitoring",
    icon: Activity,
    accent: "#f59e0b",
    shadow: "rgba(245,158,11,0.35)",
    bg: "rgba(245,158,11,0.06)",
    border: "rgba(245,158,11,0.15)",
    iconBg: "rgba(245,158,11,0.1)",
    hoverBorder: "rgba(245,158,11,0.5)",
  },
];

export function StatsBar({ viruses = [] }: { viruses?: Virus[] }) {
  const values = {
    total:    viruses.length,
    bsl4:     viruses.filter(v => v.risk === 4).length,
    families: new Set(viruses.map(v => v.family)).size,
    emerging: viruses.filter(v => v.status === "emerging" || v.status === "novel").length,
  };

  return (
    <div className="relative bg-card/90 backdrop-blur-xl border-b border-border/50 sticky top-0 z-40">
      {/* Top accent line */}
      <div className="absolute top-0 left-0 right-0 h-[1px]"
        style={{ background: "linear-gradient(90deg, transparent, #00e5ff, #a855f7, #4ade80, transparent)" }} />

      {/* Live indicator */}
      <div className="absolute top-2 right-4 flex items-center gap-1.5 z-10">
        <Wifi className="w-3 h-3 text-green-400" />
        <span className="font-mono text-[9px] text-green-400 uppercase tracking-widest">Live</span>
        <span className="relative flex h-1.5 w-1.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-60" />
          <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-green-400" />
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-0 divide-x divide-border/30">
        {STAT_CONFIG.map((cfg, i) => {
          const value = values[cfg.key as keyof typeof values];
          const Icon = cfg.icon;
          return (
            <motion.div key={cfg.key}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08, duration: 0.5 }}
              className="group relative flex items-center gap-4 px-5 py-4 overflow-hidden cursor-default transition-all duration-300"
              style={{ background: "transparent" }}
              whileHover={{ background: cfg.bg }}
            >
              {/* Hover glow */}
              <motion.div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                style={{ boxShadow: `inset 0 0 30px ${cfg.shadow}` }} />

              {/* Icon */}
              <div className="relative shrink-0 p-3 rounded-xl border transition-all duration-300 group-hover:scale-110"
                style={{ backgroundColor: cfg.iconBg, borderColor: cfg.border }}>
                <Icon size={22} style={{ color: cfg.accent, filter: `drop-shadow(0 0 8px ${cfg.accent})` }} />
              </div>

              {/* Value + Label */}
              <div className="min-w-0">
                <p className="font-orbitron text-2xl md:text-3xl font-black tracking-tight leading-none"
                  style={{ color: cfg.accent, textShadow: `0 0 20px ${cfg.shadow}` }}>
                  <AnimatedCounter value={value} duration={1000 + i * 150} />
                </p>
                <p className="font-mono text-[10px] uppercase tracking-wider mt-1" style={{ color: "rgba(148,163,184,0.7)" }}>{cfg.label}</p>
                <p className="font-mono text-[9px] mt-0.5" style={{ color: "rgba(100,116,139,0.6)" }}>{cfg.sublabel}</p>
              </div>

              {/* Bottom accent bar */}
              <motion.div className="absolute bottom-0 left-0 h-[2px] rounded-full origin-left"
                style={{ backgroundColor: cfg.accent, boxShadow: `0 0 8px ${cfg.accent}` }}
                initial={{ scaleX: 0 }} animate={{ scaleX: 1 }}
                transition={{ delay: 0.4 + i * 0.1, duration: 0.8, ease: "easeOut" }} />
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
