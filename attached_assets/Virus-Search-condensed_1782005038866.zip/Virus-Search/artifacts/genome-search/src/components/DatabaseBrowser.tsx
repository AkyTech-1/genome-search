import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Copy, Check, ExternalLink, AlertTriangle, ShieldAlert, Zap, Dna, FlaskConical } from "lucide-react";
import { useListViruses } from "@workspace/api-client-react";
import type { Virus } from "@workspace/api-client-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";

const RISK_COLORS = {
  1: "bg-green-500/20 text-green-400 border-green-500/50",
  2: "bg-amber-500/20 text-amber-400 border-amber-500/50",
  3: "bg-orange-500/20 text-orange-400 border-orange-500/50",
  4: "bg-red-500/20 text-red-400 border-red-500/50 shadow-[0_0_10px_rgba(239,68,68,0.5)]",
};

const STATUS_COLORS: Record<string, string> = {
  characterized: "bg-blue-500/20 text-blue-400 border-blue-500/50",
  emerging: "bg-amber-500/20 text-amber-400 border-amber-500/50",
  novel: "bg-red-500/20 text-red-400 border-red-500/50",
};

function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text);
  toast({
    title: "Copied to clipboard",
    description: "DNA sequence copied successfully.",
  });
}

function HighlightedSequence({ sequence }: { sequence: string }) {
  // Color nucleotides
  const colors: Record<string, string> = {
    A: "text-green-400",
    T: "text-red-400",
    G: "text-blue-400",
    C: "text-amber-400",
  };

  return (
    <div className="font-mono text-xs break-all whitespace-pre-wrap leading-relaxed">
      {sequence.split('').map((char, i) => (
        <span key={i} className={colors[char] || "text-foreground"}>{char}</span>
      ))}
    </div>
  );
}

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, scale: 0.9, y: 20 },
  show: { opacity: 1, scale: 1, y: 0, transition: { duration: 0.3 } },
  exit: { opacity: 0, scale: 0.9, y: -20, transition: { duration: 0.2 } }
};

export function DatabaseBrowser({ onRunBlast }: { onRunBlast?: (sequence: string) => void }) {
  const { data: viruses, isLoading, error } = useListViruses();
  const [search, setSearch] = useState("");
  const [riskFilter, setRiskFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [familyFilter, setFamilyFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [selectedVirus, setSelectedVirus] = useState<Virus | null>(null);

  const families = useMemo(() => {
    if (!viruses) return [];
    return Array.from(new Set(viruses.map(v => v.family))).sort();
  }, [viruses]);

  const filteredViruses = useMemo(() => {
    if (!viruses) return [];
    return viruses.filter(v => {
      const matchSearch = v.name.toLowerCase().includes(search.toLowerCase()) || 
                          v.family.toLowerCase().includes(search.toLowerCase()) ||
                          v.genus.toLowerCase().includes(search.toLowerCase());
      const matchRisk = riskFilter === "all" || v.risk.toString() === riskFilter;
      const matchStatus = statusFilter === "all" || v.status === statusFilter;
      const matchFamily = familyFilter === "all" || v.family === familyFilter;
      return matchSearch && matchRisk && matchStatus && matchFamily;
    }).sort((a, b) => {
      if (sortBy === "name") return a.name.localeCompare(b.name);
      if (sortBy === "risk") return b.risk - a.risk; // Highest risk first
      if (sortBy === "year") return b.discovered - a.discovered; // Newest first
      if (sortBy === "size") return b.genome_kb - a.genome_kb; // Largest first
      return 0;
    });
  }, [viruses, search, riskFilter, statusFilter, familyFilter, sortBy]);

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <div className="flex gap-4">
          <Skeleton className="h-10 w-full max-w-sm" />
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-48 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 text-center text-destructive">
        <AlertTriangle className="mx-auto mb-4 w-12 h-12" />
        <p>Failed to load pathogen database.</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Filters Bar */}
      <div className="flex flex-col xl:flex-row gap-4 items-start xl:items-center justify-between p-4 bg-card border border-border rounded-xl shadow-[0_0_20px_rgba(0,0,0,0.5)]">
        <div className="relative w-full xl:max-w-md group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4 group-focus-within:text-cyan-400 transition-colors" />
          <Input 
            placeholder="Search by name, family, genus..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-background border-border/50 focus-visible:ring-cyan-400 focus-visible:border-cyan-400 focus-visible:shadow-[0_0_15px_rgba(0,229,255,0.3)] transition-all font-mono text-sm"
          />
        </div>
        
        <div className="flex flex-wrap gap-3 w-full xl:w-auto relative">
          <Select value={riskFilter} onValueChange={setRiskFilter}>
            <SelectTrigger className="w-[140px] font-mono text-xs hover:border-cyan-400/50 hover:shadow-[0_0_10px_rgba(0,229,255,0.2)] transition-all relative overflow-hidden">
              <SelectValue placeholder="BSL Risk" />
              {riskFilter !== 'all' && (
                <motion.div layoutId="activeFilter" className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 shadow-[0_0_5px_#00e5ff]" />
              )}
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Risks</SelectItem>
              <SelectItem value="1">BSL-1</SelectItem>
              <SelectItem value="2">BSL-2</SelectItem>
              <SelectItem value="3">BSL-3</SelectItem>
              <SelectItem value="4">BSL-4</SelectItem>
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px] font-mono text-xs hover:border-cyan-400/50 hover:shadow-[0_0_10px_rgba(0,229,255,0.2)] transition-all relative overflow-hidden">
              <SelectValue placeholder="Status" />
              {statusFilter !== 'all' && (
                <motion.div layoutId="activeFilter2" className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 shadow-[0_0_5px_#00e5ff]" />
              )}
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="characterized">Characterized</SelectItem>
              <SelectItem value="emerging">Emerging</SelectItem>
              <SelectItem value="novel">Novel</SelectItem>
            </SelectContent>
          </Select>

          <Select value={familyFilter} onValueChange={setFamilyFilter}>
            <SelectTrigger className="w-[180px] font-mono text-xs hover:border-cyan-400/50 hover:shadow-[0_0_10px_rgba(0,229,255,0.2)] transition-all relative overflow-hidden">
              <SelectValue placeholder="Family" />
              {familyFilter !== 'all' && (
                <motion.div layoutId="activeFilter3" className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 shadow-[0_0_5px_#00e5ff]" />
              )}
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Families</SelectItem>
              {families.map(f => (
                <SelectItem key={f} value={f}>{f}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[160px] font-mono text-xs border-primary/50 text-primary hover:shadow-[0_0_10px_rgba(0,229,255,0.2)] transition-all">
              <SelectValue placeholder="Sort By" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name (A-Z)</SelectItem>
              <SelectItem value="risk">Risk Level (High-Low)</SelectItem>
              <SelectItem value="year">Discovery (New-Old)</SelectItem>
              <SelectItem value="size">Genome Size (Large-Small)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Grid */}
      <motion.div
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"
        variants={containerVariants}
        initial="hidden"
        animate="show"
      >
        <AnimatePresence mode="popLayout">
          {filteredViruses.map((v) => {
            const riskAccent = { 1: "#4ade80", 2: "#f59e0b", 3: "#f97316", 4: "#ef4444" }[v.risk] ?? "#00e5ff";
            const riskShadow = { 1: "rgba(74,222,128,0.25)", 2: "rgba(245,158,11,0.25)", 3: "rgba(249,115,22,0.25)", 4: "rgba(239,68,68,0.4)" }[v.risk] ?? "transparent";
            const genomePct = Math.min(100, (v.genome_kb / 200) * 100);
            return (
              <motion.div layout variants={itemVariants} key={v.id} className="relative" whileHover={{ y: -6 }}>
                <motion.div
                  onClick={() => setSelectedVirus(v)}
                  className="group cursor-pointer relative rounded-2xl bg-card overflow-hidden border transition-all duration-300"
                  style={{ borderColor: `${riskAccent}22` }}
                  whileHover={{ borderColor: `${riskAccent}70`, boxShadow: `0 0 0 1px ${riskAccent}40, 0 16px 48px rgba(0,0,0,0.7), 0 0 40px ${riskShadow}` }}
                  animate={v.risk === 4 ? {
                    boxShadow: ["0 0 0 1px rgba(239,68,68,0.1), 0 0 20px rgba(239,68,68,0)", "0 0 0 1px rgba(239,68,68,0.35), 0 0 30px rgba(239,68,68,0.15)", "0 0 0 1px rgba(239,68,68,0.1), 0 0 20px rgba(239,68,68,0)"]
                  } : {}}
                  transition={v.risk === 4 ? { duration: 2.5, repeat: Infinity, ease: "easeInOut" } : { duration: 0.2 }}
                >
                  {/* Left accent bar */}
                  <div className="absolute left-0 top-0 bottom-0 w-[3px] rounded-l-2xl"
                    style={{ backgroundColor: riskAccent, boxShadow: `0 0 12px ${riskAccent}` }} />

                  {/* Hover shimmer */}
                  <motion.div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                    style={{ background: `radial-gradient(ellipse at 50% 0%, ${riskAccent}0a 0%, transparent 70%)` }} />

                  <div className="pl-5 pr-4 pt-4 pb-4 space-y-3">
                    {/* Top badges */}
                    <div className="flex justify-between items-center">
                      <span className="font-orbitron text-[10px] font-bold tracking-widest px-2 py-0.5 rounded"
                        style={{ color: riskAccent, backgroundColor: `${riskAccent}18`, border: `1px solid ${riskAccent}35` }}>
                        BSL-{v.risk}
                      </span>
                      <Badge variant="outline" className={`font-mono text-[10px] capitalize ${STATUS_COLORS[v.status]}`}>
                        {v.status === "novel" && <AlertTriangle className="w-2.5 h-2.5 mr-1 inline" />}
                        {v.status}
                      </Badge>
                    </div>

                    {/* Name + family */}
                    <div>
                      <h3 className="font-bold text-base tracking-tight leading-snug group-hover:transition-colors truncate"
                        style={{ color: "hsl(var(--foreground))" }}
                        title={v.name}>
                        <span className="group-hover:text-transparent group-hover:bg-clip-text transition-all duration-300"
                          style={{ backgroundImage: `linear-gradient(90deg, #ffffff, ${riskAccent})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "inherit" } as any}>
                          {v.name}
                        </span>
                      </h3>
                      <p className="text-[10px] text-muted-foreground font-mono mt-0.5 truncate">{v.family} · {v.genus}</p>
                    </div>

                    {/* Stats row */}
                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                      <div className="bg-background/60 rounded-lg px-2.5 py-2 border border-border/40">
                        <span className="text-muted-foreground block mb-0.5 uppercase tracking-wider" style={{ fontSize: "9px" }}>Discovered</span>
                        <span className="font-bold" style={{ color: riskAccent }}>{v.discovered}</span>
                      </div>
                      <div className="bg-background/60 rounded-lg px-2.5 py-2 border border-border/40">
                        <span className="text-muted-foreground block mb-0.5 uppercase tracking-wider" style={{ fontSize: "9px" }}>Genome</span>
                        <span className="font-bold text-foreground">{v.genome_kb} kb</span>
                      </div>
                    </div>

                    {/* Genome size bar */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-[9px] font-mono text-muted-foreground uppercase tracking-wider">Genome Size</span>
                        <span className="text-[9px] font-mono" style={{ color: riskAccent }}>{genomePct.toFixed(0)}%</span>
                      </div>
                      <div className="h-[3px] bg-background rounded-full overflow-hidden">
                        <motion.div className="h-full rounded-full"
                          style={{ backgroundColor: riskAccent, boxShadow: `0 0 6px ${riskAccent}` }}
                          initial={{ width: 0 }} animate={{ width: `${genomePct}%` }}
                          transition={{ duration: 0.9, delay: 0.2, ease: "easeOut" }} />
                      </div>
                    </div>
                  </div>

                  {/* Click hint */}
                  <div className="absolute bottom-2 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <span className="font-mono text-[8px] uppercase tracking-widest" style={{ color: riskAccent }}>→ View Details</span>
                  </div>
                </motion.div>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {filteredViruses.length === 0 && (
          <div className="col-span-full py-16 text-center">
            <p className="font-mono text-muted-foreground text-sm">No pathogens matched your criteria.</p>
          </div>
        )}
      </motion.div>

      {/* Details Sheet */}
      <Sheet open={!!selectedVirus} onOpenChange={(open) => !open && setSelectedVirus(null)}>
        <SheetContent className="w-full sm:max-w-xl md:max-w-2xl bg-card/95 backdrop-blur-xl border-l-border overflow-y-auto p-0">
          {selectedVirus && (
            <div className="p-6">
              <SheetHeader className="mb-6 border-b border-border pb-6">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className={`font-mono ${RISK_COLORS[selectedVirus.risk as keyof typeof RISK_COLORS]}`}>
                    BSL-{selectedVirus.risk}
                  </Badge>
                  <Badge variant="outline" className={`font-mono capitalize ${STATUS_COLORS[selectedVirus.status]}`}>
                    {selectedVirus.status}
                  </Badge>
                  <Badge variant="outline" className="font-mono bg-secondary text-secondary-foreground border-secondary">
                    {selectedVirus.genome_kb} kb
                  </Badge>
                </div>
                <SheetTitle className="text-3xl font-bold tracking-tighter text-foreground">{selectedVirus.fullname}</SheetTitle>
                <SheetDescription className="text-sm font-mono text-muted-foreground">
                  {selectedVirus.family} &bull; {selectedVirus.genus} &bull; Discovered {selectedVirus.discovered}
                </SheetDescription>
              </SheetHeader>

              <div className="space-y-8">
                <section>
                  <h4 className="text-sm font-semibold uppercase tracking-wider text-primary mb-3 flex items-center gap-2">
                    <Zap className="w-4 h-4" /> Intelligence Brief
                  </h4>
                  <p className="text-sm leading-relaxed text-muted-foreground bg-background/50 p-4 rounded-xl border border-border">
                    {selectedVirus.description}
                  </p>
                </section>

                <section>
                  <h4 className="text-sm font-semibold uppercase tracking-wider text-primary mb-3 flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4" /> Characteristics
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedVirus.characteristics.map(c => (
                      <span key={c} className="px-2 py-1 bg-secondary border border-secondary text-xs rounded-md text-secondary-foreground font-mono">
                        {c.includes('⚠') ? <span className="text-destructive font-bold">{c}</span> : c}
                      </span>
                    ))}
                  </div>
                </section>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-background/50 p-4 rounded-xl border border-border">
                    <span className="text-xs text-muted-foreground uppercase tracking-widest block mb-1">Host Species</span>
                    <span className="text-sm font-mono">{selectedVirus.host}</span>
                  </div>
                  <div className="bg-background/50 p-4 rounded-xl border border-border">
                    <span className="text-xs text-muted-foreground uppercase tracking-widest block mb-1">Accession</span>
                    <a 
                      href={`https://www.ncbi.nlm.nih.gov/nuccore/${selectedVirus.accession}`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-sm font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                    >
                      {selectedVirus.accession} <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>

                <section>
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-sm font-semibold uppercase tracking-wider text-primary flex items-center gap-2">
                      <Dna className="w-4 h-4" /> Genomic Sequence
                    </h4>
                    <div className="flex items-center gap-2">
                      {onRunBlast && (
                        <Button
                          size="sm"
                          onClick={() => {
                            onRunBlast(selectedVirus.sequence);
                            setSelectedVirus(null);
                          }}
                          className="h-8 text-xs font-mono bg-cyan-500/20 hover:bg-cyan-500/40 text-cyan-300 border border-cyan-500/60 hover:border-cyan-400 shadow-[0_0_8px_rgba(0,229,255,0.3)] hover:shadow-[0_0_14px_rgba(0,229,255,0.6)] transition-all"
                        >
                          <FlaskConical className="w-3 h-3 mr-1.5" /> Run BLAST
                        </Button>
                      )}
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => copyToClipboard(selectedVirus.sequence)}
                        className="h-8 w-8 p-0 hover:bg-primary/20 hover:text-primary border-primary/50"
                        title="Copy sequence"
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <div className="bg-black p-4 rounded-xl border border-border max-h-[300px] overflow-y-auto">
                    <HighlightedSequence sequence={selectedVirus.sequence} />
                  </div>
                </section>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
