import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Loader2, Database, AlertCircle, FileText, CheckCircle2 } from "lucide-react";
import { useBlastSubmit, useBlastResults } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { BlastAnalysis } from "./BlastAnalysis";

const EXAMPLES = {
  "SARS-CoV-2 (Spike)": "ATGTTTGTTTTTCTTGTTTTATTGCCACTAGTCTCTAGTCAGTGTGTTAATCTTACAACCAGAACTCAATTACCCCCTGCATACACTAATTCTTTCACACGTGGTGTTTATTACCCTGACAAAGTTTTCAGATCCTCAGTTTTACATTCAACTCAGGACTTGTTCTTACCTTTCTTTTCCAATGTTACTTGGTTCCATGCTATACATGTCTCTGGGACCAATGGTACTAAGAGGTTTGATAACCCTGTCCTACCATTTAATGATGGTGTTTATTTTGCTTCCACTGAGAAGTCTAACATAATAAGAGGCTGGATTTTTGGTACTACTTTAGATTCGAAGACCCAGTCCCTACTTATTGTTAATAACGCTACTAATGTTGTTATTAAAGTCTGTGAATTTCAATTTTGTAATGATCCATTTTTGGGTGTTTATTACCACAAAAACAACAAAAGTTGGATGGAAAGTGAG",
  "Ebola (GP snippet)": "ATGGGCGTTACAGGAATATTGCAGTTACCTCGTGATCGATTCAAGAGGACATCATTCTTTCTTTGGGTAATTATCCTTTTCCAAAGAACATTTTCCATCCCACTTGGAGTCATCCACAATAGCACATTACAGGTTAGTGATGTCGACAAACTAGTTTGTCGTGACAAACTGTCATCCACAAATCAATTGAGATCAGTTGGACTGAATCTCGAAGGGAATGGAGTGGCAACTGACGTGCCATCTGCAACTAAAAGATGGGGCTTCAGGTCCGGTGTCCCACCAAAGGTGGTCAATTATGAAGCTGGTGAATGGGCTGAAAACTGCTACAATCTTGAAATCAAAAAACCTGACGGGAGTGAGTGTCTACCAGCAGCGCCAGACGGGATTCGGGGCTTCCCCCGGTGCCGGTATGTGCACAAAGTATCAGGAACGGGACCGTGTGCCGGAGA",
  "HIV-1 (env)": "ATGAGAGTGAAGGGGATCAGGAAGAATTATCAGCACTTGTGGAAATGGGGCATCATGCTCCTTGGGATGTTGATGATCTGTAGTGCTACAGAAAAATTGTGGGTCACAGTCTATTATGGGGTACCTGTGTGGAAAGAAGCAACCACCACTCTATTTTGTGCATCAGATGCTAAAGCATATGATACAGAGGTACATAATGTTTGGGCCACACATGCCTGTGTACCCACAGACCCCAACCCACAAGAAGTAGTATTGGTAAATGTGACAGAAAATTTTAACATGTGGAAAAATGACATGGTAGAACAGATGCATGAGGATATAATCAGTTTATGGGATCAAAGCCTAAAGCCATGTGTAAAATTAACCCCACTCTGTGTTAGTTTAAAGTGCACTGATTTGAAGAATGATACTAATACCAATAGTAGTAGCGGGAGAATG",
  "H5N1 Influenza (HA)": "ATGAAGGCAATACTAGTAGTTATGCTATATACATTCGCAAGCATGGCAATAGTCAAAAGCAATCGGGCAGATAATACTAATATTAGTTTCAGAGAATACAAATGCAGACAATCTTGGAAATGAGAATGGACTTCTTCTCAACACTAACCAGTCTGTCAATGGTAACAATGGCTATCACTGGCAAAGACAATGGTATACCAATGATAATGGAGAGGATGGTCTTCAGAAACCGAACCGACCAGAGAATGAATGGGAAGTATAGGGATTTTGTCACTCAAATGCAAACACCAGATGGATGTGTTACCAAACTGCAGGATGTCTTCTGGTATCAATGCGCAGGAAATGCCAAATCAATGCAAATTACCAAACAGAGCAAAGCAAATCATCACAATCATGGAGAGAGGAGCTTCTTTCCTTGGTCTGACTTCAATGGTGCAAGATCAAATGCA",
};

export function BlastSearch({ initialSequence }: { initialSequence?: string }) {
  const [sequence, setSequence] = useState(initialSequence ?? "");
  const [rid, setRid] = useState<string | null>(null);

  const submitMutation = useBlastSubmit();

  useEffect(() => {
    if (!initialSequence) return;
    setSequence(initialSequence);
    setRid(null);
    submitMutation.mutate(
      { data: { sequence: initialSequence } },
      { onSuccess: (data) => { setRid(data.rid); } }
    );
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialSequence]);

  const { data: pollResult, error: pollError } = useBlastResults(
    { rid: rid! },
    {
      query: {
        enabled: !!rid,
        refetchInterval: (query: any) => {
          if (query.state.data?.status === "done" || query.state.error) return false;
          return 3000;
        }
      } as any
    }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sequence.trim() || sequence.length < 50) return;
    setRid(null);
    submitMutation.mutate(
      { data: { sequence } },
      { onSuccess: (data) => { setRid(data.rid); } }
    );
  };

  const status = pollResult?.status || (submitMutation.isPending ? "submitting" : "idle");
  const hits: Array<{ accession: string; title: string; score: number; evalue: string; identity: number }> = pollResult?.status === "done" ? (pollResult as any).hits ?? [] : [];

  const bpCount = sequence.replace(/\s/g, '').length;
  const canSubmit = bpCount >= 50 && status !== "waiting" && status !== "submitting";

  return (
    <div className="p-6 space-y-6">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
            <Search className="w-7 h-7 text-cyan-400" style={{ filter: "drop-shadow(0 0 8px #00e5ff)" }} />
          </div>
          <div>
            <h2 className="font-orbitron text-2xl md:text-3xl font-bold tracking-tight text-foreground">
              BLAST <span className="shimmer-text">Sequence Search</span>
            </h2>
            <p className="text-muted-foreground font-mono text-xs mt-1.5 tracking-wide">
              NCBI nucleotide alignment → 10-layer genomic intelligence analysis
            </p>
          </div>
        </div>

        {/* Terminal-style form */}
        <form onSubmit={handleSubmit} className="rounded-2xl overflow-hidden border border-cyan-500/20 shadow-[0_0_40px_rgba(0,229,255,0.06)]"
          style={{ background: "hsl(230 15% 7%)" }}>

          {/* Terminal titlebar */}
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-border/50"
            style={{ background: "hsl(230 15% 9%)" }}>
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/60" />
                <div className="w-3 h-3 rounded-full bg-amber-500/60" />
                <div className="w-3 h-3 rounded-full bg-green-500/60" />
              </div>
              <span className="font-mono text-[10px] text-muted-foreground ml-2 tracking-widest uppercase">ncbi-blast-terminal v2.16</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="font-mono text-[9px] text-green-400 uppercase tracking-widest">Connected</span>
            </div>
          </div>

          {/* Example presets */}
          <div className="px-4 pt-3 pb-2 flex flex-wrap gap-2 items-center border-b border-border/30">
            <span className="font-mono text-[9px] text-cyan-400/60 uppercase tracking-widest mr-1">$ load_example</span>
            {Object.entries(EXAMPLES).map(([name, seq]) => (
              <button key={name} type="button"
                onClick={() => setSequence(seq)}
                className="font-mono text-[10px] px-2.5 py-1 rounded-md border transition-all duration-200 hover:scale-105"
                style={{
                  color: "#00e5ff", borderColor: "rgba(0,229,255,0.2)",
                  backgroundColor: "rgba(0,229,255,0.05)",
                }}
                onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.backgroundColor = "rgba(0,229,255,0.12)"; (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(0,229,255,0.5)"; (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 0 10px rgba(0,229,255,0.2)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.backgroundColor = "rgba(0,229,255,0.05)"; (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(0,229,255,0.2)"; (e.currentTarget as HTMLButtonElement).style.boxShadow = "none"; }}
              >
                {name}
              </button>
            ))}
          </div>

          {/* Sequence input */}
          <div className="relative">
            <div className="absolute left-4 top-3 font-mono text-[9px] text-cyan-400/40 uppercase tracking-widest pointer-events-none">
              &gt; sequence_input
            </div>
            <Textarea
              value={sequence}
              onChange={e => setSequence(e.target.value.toUpperCase().replace(/[^ACGTNRYSWKMBDHV\s]/g, ''))}
              placeholder="ATGCGTAGCTAGCTGATCGTAGCTAGCTGATCG... (min 50bp)"
              className="min-h-[160px] font-mono text-xs bg-transparent border-0 border-b border-border/30 rounded-none focus-visible:ring-0 focus-visible:border-cyan-400/50 pt-8 px-4 pb-3 uppercase break-all resize-y text-green-300/90 placeholder:text-muted-foreground/30 transition-colors"
              style={{ caretColor: "#00e5ff" }}
            />
          </div>

          {/* Footer bar */}
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-4">
              <span className="font-mono text-[10px]" style={{ color: bpCount >= 50 ? "#4ade80" : "#64748b" }}>
                {bpCount} bp {bpCount >= 50 ? "✓ ready" : `· need ${50 - bpCount} more`}
              </span>
              {bpCount > 0 && (
                <div className="w-24 h-[2px] bg-background rounded-full overflow-hidden">
                  <motion.div className="h-full rounded-full"
                    style={{ backgroundColor: bpCount >= 50 ? "#4ade80" : "#f59e0b" }}
                    animate={{ width: `${Math.min(100, (bpCount / 50) * 100)}%` }}
                    transition={{ duration: 0.3 }} />
                </div>
              )}
            </div>
            <motion.button type="submit" disabled={!canSubmit}
              className="font-orbitron text-xs font-bold px-6 py-2.5 rounded-xl uppercase tracking-widest transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: canSubmit ? "linear-gradient(135deg, rgba(0,229,255,0.15), rgba(168,85,247,0.15))" : "transparent",
                border: canSubmit ? "1px solid rgba(0,229,255,0.5)" : "1px solid rgba(255,255,255,0.1)",
                color: canSubmit ? "#00e5ff" : "#64748b",
                boxShadow: canSubmit ? "0 0 20px rgba(0,229,255,0.2), inset 0 0 20px rgba(0,229,255,0.05)" : "none",
              }}
              whileHover={canSubmit ? { scale: 1.03, boxShadow: "0 0 30px rgba(0,229,255,0.4), inset 0 0 20px rgba(0,229,255,0.08)" } : {}}
              whileTap={canSubmit ? { scale: 0.97 } : {}}
            >
              {(status === "waiting" || status === "submitting") ? (
                <span className="flex items-center gap-2"><Loader2 className="w-3.5 h-3.5 animate-spin" />Processing…</span>
              ) : (
                <span className="flex items-center gap-2"><Search className="w-3.5 h-3.5" />Run BLAST + Analyse</span>
              )}
            </motion.button>
          </div>
        </form>

        {/* Pipeline status */}
        <AnimatePresence>
          {(status !== "idle" || submitMutation.isError || pollError) && (
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className={`rounded-2xl border overflow-hidden relative ${(submitMutation.isError || pollError) ? "border-destructive/40" : "border-cyan-500/20"}`}
              style={{ background: "hsl(230 15% 7%)" }}>

              {/* Matrix rain bg when searching */}
              {status === "waiting" && (
                <div className="absolute inset-0 overflow-hidden opacity-[0.07] pointer-events-none z-0">
                  <motion.div className="font-mono text-[8px] text-green-400 break-all leading-[1.1] whitespace-pre-wrap"
                    animate={{ y: [0, -800] }} transition={{ repeat: Infinity, duration: 15, ease: "linear" }}>
                    {Array.from({ length: 80 }).map(() => "ATGCGTAGCTAGCTAGCTGATCGTAGCTAGCTAGCTGATCGTAGCTAGCTAGCT").join("\n")}
                  </motion.div>
                </div>
              )}

              <div className="px-6 pt-5 pb-6 relative z-10">
                <div className="flex items-center justify-between mb-6">
                  <span className="font-orbitron text-xs font-bold uppercase tracking-widest text-cyan-400">Pipeline Status</span>
                  {status === "waiting" && (
                    <span className="font-mono text-[9px] text-green-400 uppercase tracking-widest animate-pulse">Searching NCBI…</span>
                  )}
                  {status === "done" && (
                    <span className="font-mono text-[9px] text-green-400 uppercase tracking-widest">Analysis Complete ✓</span>
                  )}
                </div>

                <div className="flex items-center justify-between relative px-4">
                  <div className="absolute left-10 right-10 top-6 h-[2px] bg-border/40 -z-10" />
                  {status !== "idle" && (
                    <motion.div initial={{ scaleX: 0 }}
                      animate={{ scaleX: status === "done" ? 1 : status === "waiting" ? 0.5 : 0.15 }}
                      className="absolute left-10 right-10 top-6 h-[2px] -z-10 origin-left"
                      style={{ background: "linear-gradient(90deg, #00e5ff, #a855f7)", boxShadow: "0 0 12px #00e5ff", transition: "transform 1s ease" }} />
                  )}
                  <PipelineStep label="Submit" icon={FileText}
                    active={status === "submitting" || status === "waiting" || status === "done"}
                    loading={status === "submitting"} done={status === "waiting" || status === "done"} />
                  <PipelineStep label="Search" icon={Database}
                    active={status === "waiting" || status === "done"}
                    loading={status === "waiting"} done={status === "done"} showHelix={status === "waiting"} />
                  <PipelineStep label="Analyse" icon={CheckCircle2}
                    active={status === "done"} loading={false} done={status === "done"} />
                </div>

                {(submitMutation.isError || pollError) && (
                  <div className="mt-6 p-4 bg-destructive/10 border border-destructive/20 text-destructive rounded-xl flex items-center justify-between gap-3 font-mono text-xs">
                    <div className="flex gap-3 items-center">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <p>{(submitMutation.error as any)?.response?.data?.error || (pollError as any)?.response?.data?.error || "An error occurred. Please try again."}</p>
                    </div>
                    <Button size="sm" variant="destructive" className="h-7 text-xs shrink-0" onClick={() => { setRid(null); submitMutation.reset(); }}>
                      Retry
                    </Button>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Full analysis — always rendered when done */}
        {status === "done" && (
          <BlastAnalysis hits={hits} sequence={sequence} />
        )}
      </div>
    </div>
  );
}

function PipelineStep({ label, icon: Icon, active, loading, done, showHelix }: {
  label: string; icon: any; active: boolean; loading: boolean; done: boolean; showHelix?: boolean;
}) {
  return (
    <div className="flex flex-col items-center gap-3 bg-transparent z-10">
      <motion.div
        animate={active ? { boxShadow: ["0 0 0px rgba(0,229,255,0)", "0 0 20px rgba(0,229,255,0.5)", "0 0 0px rgba(0,229,255,0)"] } : {}}
        transition={{ duration: 2, repeat: Infinity }}
        className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all duration-500 relative bg-card
        ${done ? 'bg-cyan-950 text-cyan-400 border-cyan-400 shadow-[0_0_15px_rgba(0,229,255,0.4)]' :
          active ? 'bg-background text-cyan-400 border-cyan-400' :
          'bg-background text-muted-foreground border-muted-foreground/30'}`}
      >
        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Icon className="w-5 h-5" />}
        {active && !done && (
          <motion.div className="absolute inset-[-4px] rounded-full border border-cyan-400/50"
            animate={{ scale: [1, 1.3], opacity: [1, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }} />
        )}
        {showHelix && (
          <motion.div animate={{ rotateY: 360 }} transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
            className="absolute -right-8 top-1/2 -translate-y-1/2 text-xl text-green-400 drop-shadow-[0_0_5px_#00ff88]">
            🧬
          </motion.div>
        )}
      </motion.div>
      <span className={`text-xs font-mono uppercase tracking-wider ${active ? 'text-cyan-400 font-bold drop-shadow-[0_0_5px_#00e5ff]' : 'text-muted-foreground'}`}>
        {label}
      </span>
    </div>
  );
}
