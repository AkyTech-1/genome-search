import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Hero } from "../components/Hero";
import { StatsBar } from "../components/StatsBar";
import { DatabaseBrowser } from "../components/DatabaseBrowser";
import { BlastSearch } from "../components/BlastSearch";
import { useListViruses } from "@workspace/api-client-react";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";

export default function Home() {
  const { data: viruses, isLoading } = useListViruses();
  const [activeTab, setActiveTab] = useState("database");
  const [blastSequence, setBlastSequence] = useState<string | undefined>(undefined);

  const handleRunBlast = (sequence: string) => {
    setBlastSequence(sequence);
    setActiveTab("blast");
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col selection:bg-primary/30 selection:text-primary relative">
      {/* Top neon loading bar */}
      <AnimatePresence>
        {isLoading && (
          <motion.div 
            initial={{ opacity: 1, scaleX: 0 }}
            animate={{ opacity: 1, scaleX: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-400 via-purple-500 to-green-400 z-50 origin-left shadow-[0_0_10px_rgba(0,229,255,0.8)]"
          />
        )}
      </AnimatePresence>

      <Hero />
      <StatsBar viruses={viruses} />
      
      <main className="flex-1 w-full max-w-[1600px] mx-auto pt-8 pb-24 overflow-x-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-6 mb-6">
            <TabsList className="relative p-0 h-auto w-full max-w-lg mx-auto grid grid-cols-2 bg-transparent gap-2">
              <TabsTrigger value="database" className="group relative h-11 rounded-xl font-mono text-xs font-bold tracking-[0.15em] uppercase transition-all duration-300 border data-[state=active]:border-cyan-500/60 data-[state=active]:bg-cyan-500/10 data-[state=active]:text-cyan-300 data-[state=active]:shadow-[0_0_20px_rgba(0,229,255,0.2)] border-border/40 bg-card/60 text-muted-foreground hover:text-cyan-300 hover:border-cyan-500/40 hover:bg-cyan-500/5">
                <span className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 group-data-[state=active]:shadow-[0_0_8px_#00e5ff] opacity-50 group-data-[state=active]:opacity-100" />
                  Pathogen DB
                </span>
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 h-[2px] w-0 group-data-[state=active]:w-3/4 bg-cyan-400 rounded-full transition-all duration-300 shadow-[0_0_6px_#00e5ff]" />
              </TabsTrigger>
              <TabsTrigger value="blast" className="group relative h-11 rounded-xl font-mono text-xs font-bold tracking-[0.15em] uppercase transition-all duration-300 border data-[state=active]:border-purple-500/60 data-[state=active]:bg-purple-500/10 data-[state=active]:text-purple-300 data-[state=active]:shadow-[0_0_20px_rgba(168,85,247,0.2)] border-border/40 bg-card/60 text-muted-foreground hover:text-purple-300 hover:border-purple-500/40 hover:bg-purple-500/5">
                <span className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400 group-data-[state=active]:shadow-[0_0_8px_#a855f7] opacity-50 group-data-[state=active]:opacity-100" />
                  Blast Search
                </span>
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 h-[2px] w-0 group-data-[state=active]:w-3/4 bg-purple-400 rounded-full transition-all duration-300 shadow-[0_0_6px_#a855f7]" />
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="relative w-full">
            <AnimatePresence mode="wait">
              {activeTab === "database" && (
                <motion.div
                  key="database"
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 50 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                >
                  <DatabaseBrowser onRunBlast={handleRunBlast} />
                </motion.div>
              )}
              {activeTab === "blast" && (
                <motion.div
                  key="blast"
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                >
                  <BlastSearch initialSequence={blastSequence} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </Tabs>
      </main>
      
      <footer className="py-8 border-t border-border/50 mt-auto relative z-10 overflow-hidden" style={{ background: "hsl(230 15% 5%)" }}>
        <div className="absolute top-0 left-0 right-0 h-[1px]"
          style={{ background: "linear-gradient(90deg, transparent, rgba(0,229,255,0.3), rgba(168,85,247,0.3), transparent)" }} />
        <div className="max-w-[1600px] mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="font-orbitron text-[10px] font-bold tracking-widest" style={{ color: "#00e5ff" }}>VGIP</span>
            <span className="text-border/60">|</span>
            <span className="font-mono text-[10px] text-muted-foreground uppercase tracking-wider">Viral Genome Intelligence Platform · {new Date().getFullYear()}</span>
          </div>
          <div className="flex items-center gap-4 text-[9px] font-mono text-muted-foreground uppercase tracking-widest">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400" style={{ boxShadow: "0 0 6px #4ade80" }} />
              NCBI Connected
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" style={{ boxShadow: "0 0 6px #00e5ff" }} />
              49 Pathogens Indexed
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" style={{ boxShadow: "0 0 6px #f59e0b" }} />
              Threat Level: HIGH
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}